define(["require", "exports", "jquery", "lodash"], function (require, exports, $, _) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var appSettingPrefix = 'momani-settings-';
    var nodes = $('meta[itemprop]');
    var keyValuePairs = _(nodes)
        .map(function (node) {
        return { key: node.attributes['itemprop'].value, value: node.attributes['content'].value };
    })
        .filter(function (entry) { return entry.key.indexOf(appSettingPrefix) === 0; })
        .value();
    var settings = {};
    _.each(keyValuePairs, function (entry) { return settings[entry.key.substr(appSettingPrefix.length)] = entry.value; });
    function get(key) {
        return settings[key];
    }
    exports.get = get;
});
//# sourceMappingURL=appSettings.js.map