define(["require", "exports", "models/model", "services/setService", "services/parameterService", "services/variableService", "services/objectiveFunctionService", "services/constraintGroupService", "services/constraintService", "services/modelService"], function (require, exports, modelModel, setService, parameterService, variableService, objectiveFunctionService, constraintGroupService, constraintService, modelService) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [setService, parameterService, variableService, objectiveFunctionService, constraintGroupService, constraintService, modelService];
    var ModelDataController = (function () {
        function ModelDataController($scope, $routeParams, $window, $q, SetService, ParameterService, VariableService, ObjectiveFunctionService, ConstraintGroupService, ConstraintService, ModelService) {
            $scope.loading = true;
            var setReq = SetService.query().$promise;
            var parameterReq = ParameterService.query().$promise;
            var variableReq = VariableService.query().$promise;
            var objectiveFunctionReq = ObjectiveFunctionService.query().$promise;
            var constraintGroupReq = ConstraintGroupService.query().$promise;
            var constraintReq = ConstraintService.query().$promise;
            var modelReq = ModelService.get({ id: $routeParams['id'] }).$promise;
            $q.all([setReq, parameterReq, variableReq, objectiveFunctionReq, constraintGroupReq, constraintReq, modelReq]).then(function (res) {
                $scope.model = new modelModel.Model(res[0], res[1], res[2], res[3], res[4], res[5], res[6]);
                $scope.loading = false;
            });
            $scope.setOrderProp = 'data.name';
        }
        return ModelDataController;
    }());
    exports.ModelDataController = ModelDataController;
});
//# sourceMappingURL=modelDataControllers.js.map