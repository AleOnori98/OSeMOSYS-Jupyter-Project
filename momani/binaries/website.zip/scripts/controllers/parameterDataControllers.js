define(["require", "exports", "lodash", "models/parameterData", "models/csvData", "models/csvFiltering", "models/setData", "services/setService", "services/parameterService", "services/setDataService", "services/parameterDataService", "services/modelService", "services/scenarioService", "models/seriesLoader"], function (require, exports, _, parameterDataModel, csvData, csvFiltering, setDataModel, setService, parameterService, setDataService, parameterDataService, modelService, scenarioService, seriesLoader) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [setService, parameterService, setDataService, parameterDataService, modelService, scenarioService];
    var ParameterDataController = (function () {
        function ParameterDataController($scope, $routeParams, $window, $q, ParameterService, SetService, ParameterDataService, SetDataService, ModelService) {
            $scope.loading = true;
            var modelId = $routeParams['modelId'];
            var scenarioId = $routeParams['scenarioId'];
            var parameterId = $routeParams['parameterId'];
            var returnSetId = $routeParams['setId'];
            $scope.returnUrlSuffix = returnSetId ? "/sets/" + returnSetId : "";
            var modelReq = ModelService.get({ id: modelId }).$promise;
            var setReq = SetService.query().$promise;
            var parametersReq = ParameterService.query().$promise;
            var parameterDataReq = ParameterDataService.get({ parameterId: parameterId, scenarioId: scenarioId }).$promise;
            $q.all([setReq, parameterDataReq, parametersReq, modelReq]).then(function (res) {
                var sets = res[0];
                var parameterData = res[1];
                var allParameters = _.sortBy(res[2], function (p) { return p.name; });
                var model = res[3];
                $scope.parameters = _.filter(allParameters, function (param) { return _.some(model.parameters, function (pId) { return param.id === pId; }); });
                var parameter = _.find($scope.parameters, function (p) { return p.id === parameterId; });
                $scope.selectedParameterId = parameter.id;
                var setDataReqs = _.map(parameter.sets, function (setId) {
                    return SetDataService.get({ setId: setId, modelId: modelId }).$promise;
                });
                $q.all(setDataReqs).then(function (setDataRes) {
                    var setDatas = _.map(parameter.sets, function (setId, index) {
                        var actualSet = _.find(sets, function (s) { return s.id === setId; });
                        return new setDataModel.SetData(modelId, actualSet, setDataRes[index]);
                    });
                    $scope.data = new parameterDataModel.ParameterData(scenarioId, modelId, parameter, setDatas, parameterData);
                    $scope.loading = false;
                });
            });
            $scope.switchParameter = function () {
                var redirectHandler = function () {
                    $window.location.href = "#/models/" + modelId + "/" + scenarioId + "/data/parameter/" + $scope.selectedParameterId;
                };
                var saveBeforeRedirect = confirm('Do you want to save your current data before navigating to the selected parameter?');
                if (saveBeforeRedirect) {
                    $scope.loading = true;
                    ParameterDataService.save($scope.data.serialize(), redirectHandler, function () {
                        alert('An error occured');
                        $scope.loading = false;
                        return;
                    });
                }
                else {
                    redirectHandler();
                }
            };
            $scope.save = function () {
                $scope.loading = true;
                ParameterDataService.save($scope.data.serialize(), function () {
                    $window.location.href = "#/models/" + modelId + "/" + scenarioId + "/data" + $scope.returnUrlSuffix;
                }, function () {
                    alert('An error occured');
                    $scope.loading = false;
                });
            };
        }
        return ParameterDataController;
    }());
    exports.ParameterDataController = ParameterDataController;
    var CsvParameterDataController = (function () {
        function CsvParameterDataController($scope, $routeParams, $window, $q, ParameterService, SetService, ParameterDataService, SetDataService, ModelService, ScenarioService) {
            $scope.loading = true;
            var modelId = $routeParams['modelId'];
            var scenarioId = $routeParams['scenarioId'];
            var initialFilter = $routeParams['filterType'] ? {
                filterType: $routeParams['filterType'],
                filteredItemId: $routeParams['filteredItemId'],
                filterValue: $routeParams['filterValue'],
            } : null;
            var setReq = SetService.query().$promise;
            var parameterReq = ParameterService.query().$promise;
            var modelReq = ModelService.get({ id: modelId }).$promise;
            var scenarioReq = ScenarioService.get({ modelId: modelId, id: scenarioId }).$promise;
            $q.all([setReq, parameterReq, modelReq, scenarioReq]).then(function (res) {
                var allSets = res[0];
                var allParameters = res[1];
                $scope.model = res[2];
                $scope.scenario = res[3];
                var parameters = _.filter(allParameters, function (p) { return _.includes($scope.model.parameters, p.id); });
                if (parameters.length === 0) {
                    $scope.loading = false;
                    return;
                }
                var actualSetIds = _.uniq(_.flatten(_.map(parameters, function (p) { return p.sets; })));
                var sets = _.map(actualSetIds, function (sId) { return _.find(allSets, function (s) { return s.id === sId; }); });
                var setDataReqs = _.map(actualSetIds, function (sId) {
                    return SetDataService.get({ setId: sId, modelId: modelId }).$promise;
                });
                var parameterDataLoaderReqs = _.map(parameters, function (p) { return (function () { return ParameterDataService.get({ parameterId: p.id, scenarioId: scenarioId }).$promise; }); });
                var parameterDataLoader = new seriesLoader.SeriesLoader($q, parameterDataLoaderReqs);
                var seriesLoadingParameterDataReqs = parameterDataLoader.load();
                $q.all([$q.all(setDataReqs), seriesLoadingParameterDataReqs]).then(function (dataRes) {
                    var setDatas = dataRes[0];
                    var parameterDatas = dataRes[1];
                    $scope.data = new csvData.ParameterDataCsv(modelId, scenarioId, parameters, sets, parameterDatas, setDatas);
                    $scope.filtering = new csvFiltering.CsvDropdownFiltering(sets, setDatas, parameters, 'Parameter', $scope.data.updateFilters, initialFilter);
                    $scope.loading = false;
                });
            });
            $scope.save = function () {
                $scope.loading = true;
                var parameterDatas = $scope.data.serialize();
                var saveReqs = _.map(parameterDatas, function (parameterData) { return ParameterDataService.save(parameterData).$promise; });
                $q.all(saveReqs).then(function () {
                    $window.location.href = "#/models/" + $scope.model.id + "/" + $scope.scenario.id + "/data";
                }, function () {
                    alert('An error has occured during saving');
                    $scope.loading = false;
                });
            };
            $scope.changeColumnSet = function () {
                $scope.loading = true;
                $scope.data.clearSpreadsheet();
                setTimeout(function () {
                    $scope.data.changeColumnSet();
                    $scope.loading = false;
                }, 1);
            };
            $scope.downloadCsv = function () {
                var data = $scope.data.asTextFile();
                var blob = new Blob(data, { type: 'text/csv;charset=utf-8' });
                saveAs(blob, $scope.scenario.name + " - parameter data.csv");
            };
        }
        return CsvParameterDataController;
    }());
    exports.CsvParameterDataController = CsvParameterDataController;
});
//# sourceMappingURL=parameterDataControllers.js.map