define(["require", "exports", "controllers/modelCloningControllers", "services/modelService"], function (require, exports, modelCloningControllers, modelService) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [modelService];
    var ModelListController = (function () {
        function ModelListController($scope, $modal, ModelService) {
            $scope.loading = true;
            $scope.models = ModelService.query();
            $scope.orderProp = 'name';
            $scope.clone = function (model) {
                var modalInstance = $modal.open({
                    templateUrl: 'partials/clone-model-scenario-dialog.html',
                    controller: modelCloningControllers.ModelCloningModalController,
                    backdrop: 'static',
                    keyboard: false,
                    resolve: {
                        model: function () { return model; },
                    }
                });
                modalInstance.result.then(function () {
                    $scope.loading = true;
                    $scope.models = ModelService.query();
                    $scope.models.$promise.finally(function () {
                        $scope.loading = false;
                    });
                });
            };
            $scope.delete = function (model) {
                $scope.loading = true;
                ModelService.delete({ id: model.id }).$promise.then(function () {
                    $scope.models = ModelService.query();
                    $scope.models.$promise.finally(function () {
                        $scope.loading = false;
                    });
                });
            };
            $scope.models.$promise.finally(function () {
                $scope.loading = false;
            });
        }
        return ModelListController;
    }());
    exports.ModelListController = ModelListController;
});
//# sourceMappingURL=modelListControllers.js.map