define(["require", "exports", "lodash"], function (require, exports, _) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var EquationObjectModalController = (function () {
        function EquationObjectModalController($scope, $modalInstance, sets) {
            $scope.sets = sets;
            $scope.ok = function () {
                $modalInstance.close(_.map($scope.sets, function (set) { return set.getChanges(); }));
            };
            $scope.cancel = function () {
                $modalInstance.dismiss('cancel');
            };
        }
        return EquationObjectModalController;
    }());
    exports.EquationObjectModalController = EquationObjectModalController;
});
//# sourceMappingURL=equationObjectEditSetsController.js.map