define(["require", "exports", "urls", "services/scenarioService"], function (require, exports, urls, scenarioService) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [scenarioService];
    var ModelCloningModalController = (function () {
        function ModelCloningModalController($scope, $q, $modalInstance, $http, ScenarioService, model) {
            $scope.loading = true;
            $scope.scenarios = ScenarioService.query({ modelId: model.id });
            $scope.orderProp = 'revision';
            $scope.newName = '';
            $scope.scenarios.$promise.finally(function () {
                $scope.loading = false;
            });
            $scope.clone = function () {
                if ($scope.cloneScenarioForm.$invalid)
                    return;
                $scope.loading = true;
                var cloneReq = $http({
                    url: urls.modelCloning,
                    method: 'POST',
                    params: { modelId: model.id, scenarioId: $scope.selectedScenario.id, name: $scope.newName },
                });
                $q.when(cloneReq).finally(function () {
                    $scope.loading = false;
                }).then(function () {
                    $modalInstance.close();
                });
            };
            $scope.cancel = function () {
                $modalInstance.dismiss();
            };
        }
        return ModelCloningModalController;
    }());
    exports.ModelCloningModalController = ModelCloningModalController;
});
//# sourceMappingURL=modelCloningControllers.js.map