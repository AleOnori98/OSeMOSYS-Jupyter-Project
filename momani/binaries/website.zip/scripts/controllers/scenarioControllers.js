define(["require", "exports", "lodash", "urls", "models/model", "models/scenario", "controllers/executableRenderingControllers", "services/setService", "services/parameterService", "services/variableService", "services/objectiveFunctionService", "services/constraintGroupService", "services/constraintService", "services/modelService", "services/scenarioService", "services/setDataService", "models/tree"], function (require, exports, _, urls, modelModel, scenarioModel, executableRenderingControllers, setService, parameterService, variableService, objectiveFunctionService, constraintGroupService, constraintService, modelService, scenarioService, setDataService, tree) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [setService, parameterService, variableService, objectiveFunctionService, constraintGroupService, constraintService, modelService, scenarioService, setDataService];
    var ScenarioListController = (function () {
        function ScenarioListController($scope, $q, $http, $routeParams, $modal, ScenarioService) {
            var _this = this;
            this.loadScenarios = function () {
                _this.$scope.loading = true;
                _this.$scope.scenarioTrees = null;
                var scenarioPromise = _this.ScenarioService.query({ modelId: _this.modelId }).$promise;
                _this.$q.when(scenarioPromise).then(function (scenarios) {
                    _this.$scope.scenarios = scenarios;
                    _this.$scope.scenarioTrees = tree.getTree(scenarios, 'id', 'parentScenarioId');
                    _this.$scope.loading = false;
                });
            };
            $scope.loading = true;
            this.modelId = $routeParams['modelId'];
            this.$scope = $scope;
            this.$q = $q;
            this.ScenarioService = ScenarioService;
            this.loadScenarios();
            $scope.expandableProperty = {
                field: 'name',
                displayName: 'Name',
            };
            $scope.treeCols = [
                {
                    field: 'description',
                    displayName: 'Description',
                },
                {
                    field: 'revision',
                    displayName: 'Revision',
                },
                {
                    field: 'id',
                    displayName: '',
                    cellTemplate: "<a href=\"#/models/" + this.modelId + "/{{row.branch[col.field]}}/data\">Enter data</a>",
                },
                {
                    field: 'id',
                    displayName: '',
                    cellTemplate: "<a ng-click=\"cellTemplateScope.downloadExecutable(row.branch[col.field])\">Download executable</a>",
                    cellTemplateScope: {
                        downloadExecutable: function (scenarioId) { return _this.$scope.downloadExec(scenarioId); }
                    },
                },
                {
                    field: 'id',
                    displayName: '',
                    cellTemplate: "<a ng-click=\"cellTemplateScope.clone(row.branch[col.field])\">Clone revision</a>",
                    cellTemplateScope: {
                        clone: function (scenarioId) { return _this.$scope.clone(scenarioId); }
                    },
                },
                {
                    field: 'id',
                    displayName: '',
                    cellTemplate: "<a ng-if=\"row.branch.revision != 1\" ng-click=\"cellTemplateScope.delete(row.branch[col.field])\" confirm=\"Are you sure you want to delete the scenario {{row.branch.name}}? This will remove all the associated data and results of this and any daughter scenarios\">Delete</a>",
                    cellTemplateScope: {
                        delete: function (scenarioId) { return _this.$scope.delete(scenarioId); }
                    },
                },
            ];
            $scope.downloadExec = function (scenarioId) {
                var scenario = _.find($scope.scenarios, function (s) { return s.id == scenarioId; });
                $modal.open({
                    templateUrl: 'partials/render-executable.html',
                    controller: executableRenderingControllers.ExecutableRenderingController,
                    backdrop: 'static',
                    keyboard: false,
                    resolve: {
                        scenario: function () { return scenario; },
                    }
                });
            };
            $scope.clone = function (scenarioId) {
                $scope.loading = true;
                var cloneReq = $http({
                    url: urls.scenarioCloning,
                    method: 'POST',
                    params: { id: scenarioId },
                });
                $q.when(cloneReq).then(function () {
                    _this.loadScenarios();
                });
            };
            $scope.delete = function (scenarioId) {
                $scope.loading = true;
                ScenarioService.delete({ id: scenarioId }).$promise.then(function () {
                    _this.loadScenarios();
                });
            };
        }
        return ScenarioListController;
    }());
    exports.ScenarioListController = ScenarioListController;
    var ScenarioDetailsController = (function () {
        function ScenarioDetailsController($scope, $routeParams, $window, $q, SetService, ParameterService, VariableService, ObjectiveFunctionService, ConstraintGroupService, ConstraintService, ModelService, ScenarioService, SetDataService) {
            $scope.loading = true;
            var modelId = $routeParams['modelId'];
            var scenarioId = $routeParams['scenarioId'];
            var setReq = SetService.query().$promise;
            var parameterReq = ParameterService.query().$promise;
            var variableReq = VariableService.query().$promise;
            var objectiveFunctionReq = ObjectiveFunctionService.query().$promise;
            var constraintGroupReq = ConstraintGroupService.query().$promise;
            var constraintReq = ConstraintService.query().$promise;
            var modelReq = ModelService.get({ id: modelId }).$promise;
            var scenarioReq = ScenarioService.get({ modelId: modelId, id: scenarioId }).$promise;
            $q.all([setReq, parameterReq, variableReq, objectiveFunctionReq, constraintGroupReq, constraintReq, modelReq, scenarioReq]).then(function (res) {
                var model = new modelModel.Model(res[0], res[1], res[2], res[3], res[4], res[5], res[6]);
                $scope.scenario = new scenarioModel.Scenario(res[7]);
                $scope.setData = [];
                var setDataRequests = [];
                _.forEach(model.selectedSets(), function (s) {
                    setDataRequests.push(SetDataService.get({ setId: s.id, modelId: modelId }).$promise.then(function (setData) {
                        $scope.setData[s.id] = setData;
                    }));
                });
                $q.all(setDataRequests).then(function () {
                    $scope.model = model;
                    $scope.loading = false;
                });
            });
            $scope.parameterOrderProp = 'data.name';
            $scope.setOrderProp = 'name';
            $scope.save = function () {
                $scope.loading = true;
                ScenarioService.save($scope.scenario.serialize()).$promise.finally(function () {
                    $scope.loading = false;
                });
            };
        }
        return ScenarioDetailsController;
    }());
    exports.ScenarioDetailsController = ScenarioDetailsController;
    var SetListController = (function () {
        function SetListController($scope, $routeParams, $window, $q, SetService, ParameterService, VariableService, ObjectiveFunctionService, ConstraintGroupService, ConstraintService, ModelService) {
            $scope.loading = true;
            $scope.modelId = $routeParams['modelId'];
            $scope.scenarioId = $routeParams['scenarioId'];
            var setId = $routeParams['setId'];
            var setReq = SetService.query().$promise;
            var parameterReq = ParameterService.query().$promise;
            var variableReq = VariableService.query().$promise;
            var objectiveFunctionReq = ObjectiveFunctionService.query().$promise;
            var constraintGroupReq = ConstraintGroupService.query().$promise;
            var constraintReq = ConstraintService.query().$promise;
            var modelReq = ModelService.get({ id: $scope.modelId }).$promise;
            $scope.setOrderProp = 'name';
            $scope.parameterOrderProp = 'name';
            $q.all([setReq, parameterReq, variableReq, objectiveFunctionReq, constraintGroupReq, constraintReq, modelReq]).then(function (res) {
                var model = new modelModel.Model(res[0], res[1], res[2], res[3], res[4], res[5], res[6]);
                var parameters = _.map(model.selectedParameters(), function (p) {
                    return {
                        id: p.id,
                        name: p.name,
                        description: p.description,
                        setIds: _.map(p.sets, function (s) { return s.value; }),
                    };
                });
                $scope.sets = _.map(model.selectedSets(), function (s) {
                    return {
                        id: s.id,
                        name: s.name,
                        description: s.description,
                        parameters: _.filter(parameters, function (p) { return _.includes(p.setIds, s.id); }),
                        expanded: s.id == setId,
                    };
                });
                $scope.loading = false;
            });
        }
        return SetListController;
    }());
    exports.SetListController = SetListController;
});
//# sourceMappingURL=scenarioControllers.js.map