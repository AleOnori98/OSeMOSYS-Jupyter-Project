define(["require", "exports", "lodash", "models/variable", "models/variableResult", "models/variableResultSettings", "models/csvData", "models/csvFiltering", "services/setService", "services/variableService", "services/modelService", "services/scenarioService", "services/setDataService", "services/variableResultService", "models/csvBuilder", "models/seriesLoader"], function (require, exports, _, variableModel, variableResultModel, settingsModel, csvData, csvFiltering, setService, variableService, modelService, scenarioService, setDataService, variableResultService, csvBuilder, seriesLoader) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [setService, variableService, modelService, scenarioService, setDataService, variableResultService];
    var VariableResultListController = (function () {
        function VariableResultListController($scope, $q, $http, $routeParams, SetService, VariableService, ScenarioService, SetDataService, VariableResultService) {
            $scope.loading = true;
            var modelId = $routeParams['modelId'];
            var scenarioId = $routeParams['scenarioId'];
            var scenarioReq = ScenarioService.get({ modelId: modelId, id: scenarioId }).$promise;
            var variableResultReq = VariableResultService.query({ scenarioId: scenarioId }).$promise;
            var variableReq = VariableService.query().$promise;
            var setsReq = SetService.query().$promise;
            $q.all([scenarioReq, variableResultReq, variableReq, setsReq]).then(function (res) {
                $scope.scenario = res[0];
                var variableResults = res[1];
                var variables = res[2];
                var sets = res[3];
                $scope.variableResults = _.map(variableResults, function (variableResult) {
                    var variable = new variableModel.Variable(sets, _.find(variables, function (v) { return v.id == variableResult.variableId; }));
                    return new variableResultModel.VariableResult(variable, variableResult, sets, []);
                });
                $scope.loading = false;
            });
            $scope.orderProp = 'name';
            $scope.download = function (variableListItem) {
                if (variableListItem == null)
                    return;
                $scope.loading = true;
                var variable = variableListItem.variable;
                var variableResultReq = VariableResultService.get({ id: variable.id, scenarioId: scenarioId }).$promise;
                var setIds = _.map(variable.sets, function (set) { return set.value; });
                var setDataReqs = _.map(setIds, function (setId) {
                    return SetDataService.get({ setId: setId, modelId: modelId }).$promise;
                });
                $q.all([setsReq, variableResultReq].concat(setDataReqs)).then(function (res) {
                    var sets = res[0];
                    var variableResultData = res[1];
                    var setDatas = res.splice(2);
                    var builder = new csvBuilder.CsvBuilder(variableResultData, sets, setDatas, variable);
                    var dataBlob = builder.getCsvBlob();
                    saveAs(dataBlob, variable.name + ".csv");
                    $scope.loading = false;
                });
            };
        }
        return VariableResultListController;
    }());
    exports.VariableResultListController = VariableResultListController;
    var VariableResultChartsController = (function () {
        function VariableResultChartsController($scope, $q, $http, $routeParams, SetService, VariableService, SetDataService, VariableResultService) {
            $scope.loading = true;
            var modelId = $routeParams['modelId'];
            var scenarioId = $routeParams['scenarioId'];
            var variableId = $routeParams['variableId'];
            var variableReq = VariableService.get({ id: variableId }).$promise;
            var setsReq = SetService.query().$promise;
            var variableResultReq = VariableResultService.get({ id: variableId, scenarioId: scenarioId }).$promise;
            $q.all([variableReq, setsReq, variableResultReq]).then(function (res) {
                var variableRes = res[0];
                var sets = res[1];
                var variableResult = res[2];
                var setDataReqs = _.map(variableRes.sets, function (setId) {
                    return SetDataService.get({ setId: setId, modelId: modelId }).$promise;
                });
                $q.all(setDataReqs).then(function (setDatas) {
                    var variable = new variableModel.Variable(sets, variableRes);
                    $scope.settings = new settingsModel.VariableResultSettings();
                    $scope.variableResult = new variableResultModel.VariableResult(variable, variableResult, sets, setDatas, true, $scope.settings);
                    $scope.variableResult.addGroupDataHandler($scope.settings.updateSetData);
                    $scope.settings.addSetDataFilterSubscriber($scope.changeSetDataFilters);
                    setRangeAndDraw();
                    $scope.loading = false;
                });
            });
            $scope.updateGroupOptions = function () {
                $scope.variableResult.updateGroupOptions();
                setRangeAndDraw();
            };
            $scope.updateChart = function () {
                $scope.variableResult.selectGrouping();
                setRangeAndDraw();
            };
            $scope.changeSetDataFilters = function (setDataValues) {
                $scope.variableResult.changeSetDataFilters(setDataValues);
                setRangeAndDraw();
            };
            var setRangeAndDraw = function () {
                var min = $scope.variableResult.getMinY();
                var max = $scope.variableResult.getMaxY();
                $scope.variableResult.setYRange(min, max);
                $scope.variableResult.draw();
            };
        }
        return VariableResultChartsController;
    }());
    exports.VariableResultChartsController = VariableResultChartsController;
    var CsvVariableResultController = (function () {
        function CsvVariableResultController($scope, $q, $http, $routeParams, SetService, VariableService, SetDataService, VariableResultService, ModelService, ScenarioService) {
            $scope.loading = true;
            var modelId = $routeParams['modelId'];
            var scenarioId = $routeParams['scenarioId'];
            var setReq = SetService.query().$promise;
            var variableReq = VariableService.query().$promise;
            var modelReq = ModelService.get({ id: modelId }).$promise;
            var scenarioReq = ScenarioService.get({ modelId: modelId, id: scenarioId }).$promise;
            $q.all([setReq, variableReq, modelReq, scenarioReq]).then(function (res) {
                var allSets = res[0];
                var allVariables = res[1];
                $scope.model = res[2];
                $scope.scenario = res[3];
                var variables = _.filter(allVariables, function (p) { return _.includes($scope.model.variables, p.id); });
                if (variables.length == 0) {
                    $scope.loading = false;
                    return;
                }
                var actualSetIds = _.uniq(_.flatten(_.map(variables, function (p) { return p.sets; })));
                var sets = _.map(actualSetIds, function (sId) { return _.find(allSets, function (s) { return s.id == sId; }); });
                var setDataReqs = _.map(actualSetIds, function (sId) {
                    return SetDataService.get({ setId: sId, modelId: modelId }).$promise;
                });
                var variableResultLoaderReqs = _.map(variables, function (v) { return (function () { return VariableResultService.get({ id: v.id, scenarioId: scenarioId }).$promise; }); });
                var variableResultLoader = new seriesLoader.SeriesLoader($q, variableResultLoaderReqs);
                var seriesLoadingVariableResultReqs = variableResultLoader.load();
                $q.all([$q.all(setDataReqs), seriesLoadingVariableResultReqs]).then(function (dataRes) {
                    var setDatas = dataRes[0];
                    var variableResults = dataRes[1];
                    $scope.data = new csvData.VariableResultCsv(modelId, scenarioId, variables, sets, variableResults, setDatas);
                    $scope.filtering = new csvFiltering.CsvDropdownFiltering(sets, setDatas, variables, 'Variable', $scope.data.updateFilters);
                    $scope.loading = false;
                });
            });
            $scope.changeColumnSet = function () {
                $scope.loading = true;
                $scope.data.clearSpreadsheet();
                setTimeout(function () {
                    $scope.data.changeColumnSet();
                    $scope.loading = false;
                }, 1);
            };
            $scope.downloadCsv = function () {
                var data = $scope.data.asTextFile();
                var blob = new Blob(data, { type: 'text/csv;charset=utf-8' });
                saveAs(blob, $scope.scenario.name + " - variable results.csv");
            };
        }
        return CsvVariableResultController;
    }());
    exports.CsvVariableResultController = CsvVariableResultController;
});
//# sourceMappingURL=variableResultControllers.js.map