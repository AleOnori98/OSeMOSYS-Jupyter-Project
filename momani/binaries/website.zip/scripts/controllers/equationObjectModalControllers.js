define(["require", "exports", "lodash", "models/equationObject"], function (require, exports, _, equationObject) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var EquationObjectModalController = (function () {
        function EquationObjectModalController($scope, $modalInstance, data, availableGroups) {
            var sortedSets = _.sortBy(data.sets, 'name');
            $scope.sets = _.map(sortedSets, function (set) {
                return {
                    id: set.id,
                    display: set.abbreviation + " in " + set.name,
                };
            });
            var sortedParameters = _.sortBy(data.parameters, 'name');
            $scope.parameters = _.map(sortedParameters, function (parameter) {
                var parameterSets = _.map(parameter.sets, function (setId) { return _.find(data.sets, function (s) { return s.id == setId; }); });
                var setRenders = _.map(parameterSets, function (set, index) {
                    var previousSets = _.take(parameterSets, index);
                    var repetitions = _.filter(previousSets, function (previousSet) { return previousSet.id === set.id; }).length;
                    return _.repeat(set.abbreviation, repetitions + 1) + ' in ' + set.name;
                });
                return {
                    id: parameter.id,
                    display: parameter.name + ' {' + setRenders.join(', ') + '}',
                };
            });
            var sortedVariables = _.sortBy(data.variables, 'name');
            $scope.variables = _.map(sortedVariables, function (variable) {
                var variableSets = _.map(variable.sets, function (setId) { return _.find(data.sets, function (s) { return s.id == setId; }); });
                var setRenders = _.map(variableSets, function (set, index) {
                    var previousSets = _.take(variableSets, index);
                    var repetitions = _.filter(previousSets, function (previousSet) { return previousSet.id === set.id; }).length;
                    return _.repeat(set.abbreviation, repetitions + 1) + ' in ' + set.name;
                });
                return {
                    id: variable.id,
                    display: variable.name + ' {' + setRenders.join(', ') + '}',
                };
            });
            $scope.operators = [
                { id: '=', display: '=' },
                { id: '>', display: '>' },
                { id: '<', display: '<' },
                { id: '>=', display: '>=' },
                { id: '<=', display: '<=' },
                { id: '<>', display: '<>' },
                { id: '+', display: '+' },
                { id: '-', display: '-' },
                { id: '*', display: '*' },
                { id: '/', display: '/' },
                { id: '^', display: '^' },
                { id: '&&', display: '&&' },
                { id: '||', display: '||' },
                { id: '()', display: '( )' },
                { id: 'sum', display: 'Sum' },
                { id: 'min', display: 'Min' },
                { id: 'max', display: 'Max' },
                { id: 'ifthen', display: 'If - then' },
                { id: 'if', display: 'If - then - else' },
            ];
            $scope.empty = {
                id: null,
                display: 'Empty',
            };
            $scope.numberValue = null;
            $scope.parametersVisible = _.includes(availableGroups, equationObject.ReplaceGroupOption.Parameters);
            $scope.variablesVisible = _.includes(availableGroups, equationObject.ReplaceGroupOption.Variables);
            $scope.operatorsVisible = _.includes(availableGroups, equationObject.ReplaceGroupOption.Operators);
            $scope.numberVisible = _.includes(availableGroups, equationObject.ReplaceGroupOption.Number);
            $scope.setsVisible = _.includes(availableGroups, equationObject.ReplaceGroupOption.Sets);
            $scope.select = function (object, objectType) {
                $scope.selected = {
                    type: objectType,
                    value: object.id,
                    display: object.display,
                    innerEquation1: null,
                    innerEquation2: null,
                    innerEquation3: null,
                    setChanges: null,
                    enumeratingSets: null,
                };
            };
            $scope.selectNumber = function (value) {
                if (value == null) {
                    $scope.selected = null;
                    return;
                }
                $scope.selected = {
                    type: 'Number',
                    value: value.toString(),
                    display: value.toString(),
                    innerEquation1: null,
                    innerEquation2: null,
                    innerEquation3: null,
                    setChanges: null,
                    enumeratingSets: null,
                };
            };
            $scope.ok = function () {
                $modalInstance.close($scope.selected);
            };
            $scope.cancel = function () {
                $modalInstance.dismiss('cancel');
            };
        }
        return EquationObjectModalController;
    }());
    exports.EquationObjectModalController = EquationObjectModalController;
});
//# sourceMappingURL=equationObjectModalControllers.js.map