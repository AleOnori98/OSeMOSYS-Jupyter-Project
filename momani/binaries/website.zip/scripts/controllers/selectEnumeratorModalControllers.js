define(["require", "exports", "lodash", "models/equationObject"], function (require, exports, _, equationObject) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var SelectableEnumerator = (function () {
        function SelectableEnumerator(equationObjectSet, setObject, current) {
            var _this = this;
            this.render = function () {
                return _this.abbreviation + " in " + _this.set.name;
            };
            this.serialize = function () {
                return {
                    setId: _this.set.id,
                    abbreviation: _this.abbreviation,
                };
            };
            this.abbreviation = equationObjectSet.actualAbbreviation;
            this.set = setObject;
            this.selected = !!current;
        }
        return SelectableEnumerator;
    }());
    exports.SelectableEnumerator = SelectableEnumerator;
    var SelectEnumeratorModalController = (function () {
        function SelectEnumeratorModalController($scope, $modalInstance, $modal, data, enumerators, selected, constraint) {
            var _this = this;
            $scope.enumerators = _.map(enumerators, function (enumeratorData) {
                var set = _.find(data.sets, function (s) { return s.id == enumeratorData.setId; });
                var currentData = _.find(selected, function (sel) { return sel.set.id == enumeratorData.setId && sel.abbreviation == enumeratorData.actualAbbreviation; });
                return new SelectableEnumerator(enumeratorData, set, currentData);
            });
            this.replaceConstraint = function (equation) {
                $scope.constraint = equationObject.createEquationObject(data, equationObject.availableGroupOptions.all, _this.replaceConstraint, $modal, equation);
            };
            $scope.constraint = equationObject.createEquationObject(data, equationObject.availableGroupOptions.all, this.replaceConstraint, $modal, constraint);
            $scope.hasConstraint = !($scope.constraint instanceof equationObject.EmptyEquationObject);
            $scope.ok = function () {
                var results = {
                    enumerators: _($scope.enumerators).filter(function (e) { return e.selected; }).map(function (e) { return e.serialize(); }).value(),
                    constraint: (!$scope.hasConstraint || $scope.constraint instanceof equationObject.EmptyEquationObject) ? null : $scope.constraint.serialize(),
                };
                $modalInstance.close(results);
            };
            $scope.cancel = function () {
                $modalInstance.dismiss('cancel');
            };
        }
        return SelectEnumeratorModalController;
    }());
    exports.SelectEnumeratorModalController = SelectEnumeratorModalController;
});
//# sourceMappingURL=selectEnumeratorModalControllers.js.map