define(["require", "exports", "models/setData", "services/setService", "services/setDataService"], function (require, exports, setDataModel, setService, setDataService) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [setService, setDataService];
    var SetDataController = (function () {
        function SetDataController($scope, $routeParams, $window, $q, SetService, SetDataService) {
            $scope.loading = true;
            $scope.invalidValuesNotUnique = false;
            $scope.colorPickerOptions = defaultColorPickerOptions;
            var modelId = $routeParams['modelId'];
            var setId = $routeParams['setId'];
            var setReq = SetService.get({ id: setId }).$promise;
            var setDataReq = SetDataService.get({ setId: setId, modelId: modelId }).$promise;
            $q.all([setReq, setDataReq]).then(function (res) {
                $scope.data = new setDataModel.SetData(modelId, res[0], res[1]);
                $scope.loading = false;
            });
            $scope.save = function () {
                if ($scope.valuesForm.$invalid) {
                    return;
                }
                $scope.invalidValuesNotUnique = false;
                if (!$scope.data.valuesUnique()) {
                    $scope.invalidValuesNotUnique = true;
                    return;
                }
                $scope.loading = true;
                SetDataService.save($scope.data.serialize(), function () {
                    $window.location.href = "#/models/" + modelId + "/setData";
                }, function () {
                    alert('An error occured');
                    $scope.loading = false;
                });
            };
        }
        return SetDataController;
    }());
    exports.SetDataController = SetDataController;
    var defaultColorPickerOptions = {
        disabled: false,
        round: false,
        format: 'hex',
        hue: true,
        alpha: false,
        swatch: true,
        swatchPos: 'left',
        swatchBootstrap: true,
        swatchOnly: true,
        pos: 'bottom left',
        case: 'lower',
        inline: false,
        placeholder: '',
    };
});
//# sourceMappingURL=setDataControllers.js.map