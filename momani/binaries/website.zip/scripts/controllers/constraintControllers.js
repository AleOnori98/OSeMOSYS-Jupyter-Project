define(["require", "exports", "jquery", "models/constraintList", "models/constraint", "services/setService", "services/parameterService", "services/variableService", "services/constraintGroupService", "services/constraintService"], function (require, exports, $, constraintListModel, constraintModel, setService, parameterService, variableService, constraintGroupService, constraintService) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [setService, parameterService, variableService, constraintGroupService, constraintService];
    var ConstraintListController = (function () {
        function ConstraintListController($scope, $q, ConstraintGroupService, ConstraintService) {
            $scope.loading = true;
            var constraintGroupReq = ConstraintGroupService.query().$promise;
            var constraintReq = ConstraintService.query().$promise;
            $q.all([constraintGroupReq, constraintReq]).then(function (res) {
                var constraintGroups = res[0];
                var constraints = res[1];
                $scope.constraintList = new constraintListModel.ConstraintList(constraintGroups, constraints);
                $scope.loading = false;
            });
            $scope.query = '';
            $scope.constraintFilter = function (constraint) {
                if (constraint.constraintName == null) {
                    return true;
                }
                if (constraint.name.indexOf($scope.query) > -1) {
                    return true;
                }
                return false;
            };
        }
        return ConstraintListController;
    }());
    exports.ConstraintListController = ConstraintListController;
    var ConstraintDetailsController = (function () {
        function ConstraintDetailsController($scope, $routeParams, $window, $modal, $q, SetService, ParameterService, VariableService, ConstraintGroupService, ConstraintService) {
            $scope.loading = true;
            var setReq = SetService.query().$promise;
            var parameterReq = ParameterService.query().$promise;
            var variableReq = VariableService.query().$promise;
            var constraintGroupReq = ConstraintGroupService.query().$promise;
            var constraintReq;
            if ($routeParams['id'] === 'new') {
                var deferred = $q.defer();
                constraintReq = deferred.promise;
                deferred.resolve(null);
            }
            else {
                constraintReq = ConstraintService.get({ id: $routeParams['id'] }).$promise;
            }
            $q.all([setReq, parameterReq, variableReq, constraintGroupReq, constraintReq]).then(function (res) {
                var data = {
                    sets: res[0],
                    parameters: res[1],
                    variables: res[2],
                };
                $scope.constraint = new constraintModel.Constraint(data, $modal, res[3], res[4]);
                $scope.loading = false;
            });
            $scope.save = function () {
                if ($scope.detailsForm.$invalid)
                    return;
                $scope.loading = true;
                ConstraintService.save($scope.constraint.serialize(), function () {
                    $window.location.href = '#/constraints';
                }, function () {
                    alert('An error occured');
                    $scope.loading = false;
                });
            };
            $('.view-frame')
                .on('mouseover', '.equation-operator', function () {
                $(this).closest('.equation-composite').addClass('equation-composite-hovered');
                $(this).parent().parent().children('div').children('.equation-operator').addClass('equation-operator-hovered');
            })
                .on('mouseout', '.equation-operator', function () {
                $(this).closest('.equation-composite').removeClass('equation-composite-hovered');
                $(this).parent().parent().children('div').children('.equation-operator').removeClass('equation-operator-hovered');
            });
        }
        return ConstraintDetailsController;
    }());
    exports.ConstraintDetailsController = ConstraintDetailsController;
});
//# sourceMappingURL=constraintControllers.js.map