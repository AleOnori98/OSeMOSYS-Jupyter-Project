define(["require", "exports", "services/setService", "models/parameter", "services/parameterService"], function (require, exports, setService, parameterModel, parameterService) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [setService, parameterService];
    var ParameterListController = (function () {
        function ParameterListController($scope, ParameterService) {
            $scope.loading = true;
            $scope.parameters = ParameterService.query();
            $scope.parameters.$promise.finally(function () {
                $scope.loading = false;
            });
            $scope.orderProp = 'name';
        }
        return ParameterListController;
    }());
    exports.ParameterListController = ParameterListController;
    var ParameterDetailsController = (function () {
        function ParameterDetailsController($scope, $routeParams, $window, $q, SetService, ParameterService) {
            $scope.loading = true;
            var setReq = SetService.query().$promise;
            var parameterReq;
            if ($routeParams['id'] === 'new') {
                var deferred = $q.defer();
                parameterReq = deferred.promise;
                deferred.resolve(null);
            }
            else {
                parameterReq = ParameterService.get({ id: $routeParams['id'] }).$promise;
            }
            $q.all([setReq, parameterReq]).then(function (res) {
                $scope.parameter = new parameterModel.Parameter(res[0], res[1]);
                $scope.loading = false;
            });
            $scope.save = function () {
                if ($scope.detailsForm.$invalid)
                    return;
                $scope.loading = true;
                ParameterService.save($scope.parameter.serialize(), function () {
                    $window.location.href = '#/parameters';
                }, function () {
                    alert('An error occured');
                    $scope.loading = false;
                });
            };
        }
        return ParameterDetailsController;
    }());
    exports.ParameterDetailsController = ParameterDetailsController;
});
//# sourceMappingURL=parameterControllers.js.map