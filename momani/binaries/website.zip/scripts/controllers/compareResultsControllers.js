define(["require", "exports", "lodash", "models/variable", "models/variableResult", "models/variableResultSettings", "services/modelService", "services/scenarioService", "services/variableService", "services/setService", "services/setDataService", "services/variableResultService"], function (require, exports, _, variableModel, variableResultModel, settingsModel, modelService, scenarioService, variableService, setService, setDataService, variableResultService) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [modelService, scenarioService, variableService, setService, setDataService, variableResultService];
    var CompareResultsController = (function () {
        function CompareResultsController($scope, $q, $http, $routeParams, ModelService, ScenarioService, VariableService, SetService, SetDataService, VariableResultService) {
            $scope.loading = true;
            var modelId = $routeParams['modelId'];
            var modelReq = ModelService.get({ id: modelId }).$promise;
            var scenarioReq = ScenarioService.query({ modelId: modelId }).$promise;
            var variableReq = VariableService.query().$promise;
            var setReq = SetService.query().$promise;
            var setDataReq = SetDataService.query({ modelId: modelId }).$promise;
            $q.all([modelReq, scenarioReq, variableReq, setReq, setDataReq]).then(function (res) {
                $scope.model = res[0];
                $scope.scenarios = res[1];
                $scope.scenario1 = _.first($scope.scenarios);
                $scope.scenario2 = _.last($scope.scenarios);
                var allVariables = res[2];
                var variables = _.filter(allVariables, function (variable) { return _.some($scope.model.variables, function (v) { return v == variable.id; }); });
                $scope.variables = _.sortBy(variables, function (v) { return v.name; });
                $scope.variables.unshift({
                    id: null,
                    name: '',
                });
                $scope.variable = _.first($scope.variables);
                $scope.sets = res[3];
                $scope.setData = res[4];
                $scope.settings = new settingsModel.VariableResultSettings();
                $scope.loading = false;
            });
            $scope.updateComparison = function () {
                if ($scope.variable.id == null) {
                    return;
                }
                $scope.loading = true;
                var variable = new variableModel.Variable($scope.sets, $scope.variable);
                var leftScenarioVariableResultPromise = VariableResultService.get({ id: $scope.variable.id, scenarioId: $scope.scenario1.id }).$promise;
                var rightScenarioVariableResultPromise = VariableResultService.get({ id: $scope.variable.id, scenarioId: $scope.scenario2.id }).$promise;
                var scenarioResultPromises = [leftScenarioVariableResultPromise, rightScenarioVariableResultPromise];
                $q.all(scenarioResultPromises).then(function (res) {
                    var scenario1Result = res[0];
                    var scenario2Result = res[1];
                    $scope.scenario1VariableResult = new variableResultModel.VariableResult(variable, scenario1Result, $scope.sets, $scope.setData, true, $scope.settings);
                    $scope.scenario2VariableResult = new variableResultModel.VariableResult(variable, scenario2Result, $scope.sets, $scope.setData, true, $scope.settings);
                    $scope.scenario1VariableResult.addGroupDataHandler($scope.settings.updateSetData);
                    $scope.settings.addSetDataFilterSubscriber($scope.changeSetDataFilters);
                    setRangeAndDraw();
                    $scope.loading = false;
                });
            };
            $scope.updateGroupOptions = function () {
                $scope.scenario2VariableResult.xSet = $scope.scenario1VariableResult.xSet;
                $scope.scenario1VariableResult.updateGroupOptions();
                $scope.scenario2VariableResult.updateGroupOptions();
                setRangeAndDraw();
            };
            $scope.updateChart = function () {
                $scope.scenario2VariableResult.groupSet = $scope.scenario1VariableResult.groupSet;
                $scope.scenario1VariableResult.selectGrouping();
                $scope.scenario2VariableResult.selectGrouping();
                setRangeAndDraw();
            };
            $scope.changeSetDataFilters = function (setDataValues) {
                $scope.scenario1VariableResult.changeSetDataFilters(setDataValues);
                $scope.scenario2VariableResult.changeSetDataFilters(setDataValues);
                setRangeAndDraw();
            };
            var setRangeAndDraw = function () {
                var min1 = $scope.scenario1VariableResult.getMinY();
                var min2 = $scope.scenario2VariableResult.getMinY();
                var max1 = $scope.scenario1VariableResult.getMaxY();
                var max2 = $scope.scenario2VariableResult.getMaxY();
                var minY = _.min([min1, min2]);
                var maxY = _.max([max1, max2]);
                $scope.scenario1VariableResult.setYRange(minY, maxY);
                $scope.scenario2VariableResult.setYRange(minY, maxY);
                $scope.scenario1VariableResult.draw();
                $scope.scenario2VariableResult.draw();
            };
        }
        return CompareResultsController;
    }());
    exports.CompareResultsController = CompareResultsController;
});
//# sourceMappingURL=compareResultsControllers.js.map