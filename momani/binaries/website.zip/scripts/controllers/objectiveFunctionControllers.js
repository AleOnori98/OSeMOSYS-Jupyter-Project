define(["require", "exports", "jquery", "models/objectiveFunction", "services/setService", "services/parameterService", "services/variableService", "services/objectiveFunctionService"], function (require, exports, $, objectiveFunctionModel, setService, parameterService, variableService, objectiveFunctionService) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [setService, parameterService, variableService, objectiveFunctionService];
    var ObjectiveFunctionListController = (function () {
        function ObjectiveFunctionListController($scope, ObjectiveFunctionService) {
            $scope.loading = true;
            $scope.objectiveFunctions = ObjectiveFunctionService.query();
            $scope.objectiveFunctions.$promise.finally(function () {
                $scope.loading = false;
            });
            $scope.orderProp = 'name';
        }
        return ObjectiveFunctionListController;
    }());
    exports.ObjectiveFunctionListController = ObjectiveFunctionListController;
    var ObjectiveFunctionDetailsController = (function () {
        function ObjectiveFunctionDetailsController($scope, $routeParams, $window, $modal, $q, SetService, ParameterService, VariableService, ObjectiveFunctionService) {
            $scope.loading = true;
            var setReq = SetService.query().$promise;
            var parameterReq = ParameterService.query().$promise;
            var variableReq = VariableService.query().$promise;
            var functionReq;
            if ($routeParams['id'] === 'new') {
                var deferred = $q.defer();
                functionReq = deferred.promise;
                deferred.resolve(null);
            }
            else {
                functionReq = ObjectiveFunctionService.get({ id: $routeParams['id'] }).$promise;
            }
            $q.all([setReq, parameterReq, variableReq, functionReq]).then(function (res) {
                var data = {
                    sets: res[0],
                    parameters: res[1],
                    variables: res[2],
                };
                $scope.objectiveFunction = new objectiveFunctionModel.ObjectiveFunction(data, $modal, res[3]);
                $scope.loading = false;
            });
            $scope.save = function () {
                if ($scope.detailsForm.$invalid)
                    return;
                $scope.loading = true;
                ObjectiveFunctionService.save($scope.objectiveFunction.serialize(), function () {
                    $window.location.href = '#/functions';
                }, function () {
                    alert('An error occured');
                    $scope.loading = false;
                });
            };
            $('.view-frame')
                .on('mouseover', '.equation-operator', function () {
                $(this).closest('.equation-composite').addClass('equation-composite-hovered');
                $(this).parent().parent().children('div').children('.equation-operator').addClass('equation-operator-hovered');
            })
                .on('mouseout', '.equation-operator', function () {
                $(this).closest('.equation-composite').removeClass('equation-composite-hovered');
                $(this).parent().parent().children('div').children('.equation-operator').removeClass('equation-operator-hovered');
            });
        }
        return ObjectiveFunctionDetailsController;
    }());
    exports.ObjectiveFunctionDetailsController = ObjectiveFunctionDetailsController;
});
//# sourceMappingURL=objectiveFunctionControllers.js.map