define(["require", "exports", "services/setService", "models/variable", "services/variableService"], function (require, exports, setService, variableModel, variableService) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [setService, variableService];
    var VariableListController = (function () {
        function VariableListController($scope, VariableService) {
            $scope.loading = true;
            $scope.variables = VariableService.query();
            $scope.variables.$promise.finally(function () {
                $scope.loading = false;
            });
            $scope.orderProp = 'name';
        }
        return VariableListController;
    }());
    exports.VariableListController = VariableListController;
    var VariableDetailsController = (function () {
        function VariableDetailsController($scope, $routeParams, $window, $q, SetService, VariableService) {
            $scope.loading = true;
            var setReq = SetService.query().$promise;
            var variableReq;
            if ($routeParams['id'] === 'new') {
                var deferred = $q.defer();
                variableReq = deferred.promise;
                deferred.resolve(null);
            }
            else {
                variableReq = VariableService.get({ id: $routeParams['id'] }).$promise;
            }
            $q.all([setReq, variableReq]).then(function (res) {
                $scope.variable = new variableModel.Variable(res[0], res[1]);
                $scope.loading = false;
            });
            $scope.operators = variableModel.variableOperators;
            $scope.toggleConstraint = function ($event) {
                var checkbox = $event.target;
                $scope.variable.constraint = checkbox.checked ? new variableModel.VariableConstraint() : null;
            };
            $scope.save = function () {
                if ($scope.detailsForm.$invalid)
                    return;
                $scope.loading = true;
                VariableService.save($scope.variable.serialize(), function () {
                    $window.location.href = '#/variables';
                }, function () {
                    alert('An error occured');
                    $scope.loading = false;
                });
            };
        }
        return VariableDetailsController;
    }());
    exports.VariableDetailsController = VariableDetailsController;
});
//# sourceMappingURL=variableControllers.js.map