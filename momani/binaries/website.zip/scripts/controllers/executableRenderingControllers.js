define(["require", "exports", "lodash", "jszip", "urls", "models/model", "models/dataStringBuilder", "services/setService", "services/parameterService", "services/variableService", "services/objectiveFunctionService", "services/constraintService", "services/constraintGroupService", "services/modelService", "services/setDataService", "services/parameterDataService"], function (require, exports, _, JSZip, urls, modelModel, dataStringBuilder, setService, parameterService, variableService, objectiveFunctionService, constraintService, constraintGroupService, modelService, setDataService, parameterDataService) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [setService, parameterService, variableService, objectiveFunctionService, constraintGroupService, constraintService, modelService, setDataService, parameterDataService];
    var ExecutableRenderingController = (function () {
        function ExecutableRenderingController($scope, $q, $http, $modalInstance, SetService, ParameterService, VariableService, ObjectiveFunctionService, ConstraintGroupService, ConstraintService, ModelService, SetDataService, ParameterDataService, scenario) {
            var _this = this;
            this.loadExecutable = function () {
                _this.$scope.executableLoading = true;
                var done = _this.$q.defer();
                var executableReq = _this.$http({
                    url: urls.executable,
                    method: 'GET',
                    responseType: 'arraybuffer'
                });
                _this.$q.when(executableReq).then(function (exec) {
                    var executable = exec.data;
                    _this.zip.file('RunSimulation.exe', executable, { binary: true });
                    _this.$scope.executableLoading = false;
                    _this.$scope.executableLoaded = true;
                    done.resolve();
                });
                return done;
            };
            this.loadModel = function () {
                _this.$scope.modelLoading = true;
                var done = _this.$q.defer();
                var setReq = _this.setService.query().$promise;
                var parameterReq = _this.parameterService.query().$promise;
                var variableReq = _this.variableService.query().$promise;
                var objectiveFunctionReq = _this.objectiveFunctionService.query().$promise;
                var constraintGroupReq = _this.constraintGroupService.query().$promise;
                var constraintReq = _this.constraintService.query().$promise;
                var modelReq = _this.modelService.get({ id: _this.modelId }).$promise;
                _this.$q.all([setReq, parameterReq, variableReq, objectiveFunctionReq, constraintGroupReq, constraintReq, modelReq]).then(function (res) {
                    var sets = res[0];
                    var parameters = res[1];
                    _this.model = new modelModel.Model(sets, parameters, res[2], res[3], res[4], res[5], res[6]);
                    _this.sets = _this.model.selectedSets();
                    _this.parameters = _this.model.selectedParameters();
                    _this.zip.file('model.txt', _this.model.asTextFile().join("\r\n"));
                    _this.zip.file('metadata.txt', _this.model.asScenarioMetaDataTextFile(_this.scenarioId).join("\r\n"));
                    _this.$scope.modelLoading = false;
                    _this.$scope.modelLoaded = true;
                    done.resolve();
                });
                return done;
            };
            this.loadData = function () {
                _this.$scope.dataLoading = true;
                var done = _this.$q.defer();
                var dataBuilder = new dataStringBuilder.Builder(_this.$q, _this.setDataService, _this.parameterDataService, _this.parameters, _this.scenarioId, _this.modelId, _this.sets);
                _this.$scope.dataProgress = "0/" + _this.parameters.length;
                _this.$q.when(_this.loadParameters(dataBuilder, _this.parameters.map(function (p) { return p.id; })).promise).then(function () {
                    dataBuilder.build().then(function (data) {
                        _this.zip.file('data.txt', data);
                        _this.$scope.dataLoading = false;
                        _this.$scope.dataLoaded = true;
                        done.resolve();
                    });
                });
                return done;
            };
            this.loadParameters = function (dataBuilder, parameterIds) {
                var loaded = _this.$q.defer();
                _this.$q.when(dataBuilder.addParameter(_.first(parameterIds)).promise).then(function () {
                    parameterIds.shift();
                    _this.$scope.dataProgress = _this.parameters.length - parameterIds.length + "/" + _this.parameters.length;
                    if (parameterIds.length == 0) {
                        loaded.resolve();
                    }
                    else {
                        _this.$q.when(_this.loadParameters(dataBuilder, parameterIds).promise).then(function () {
                            loaded.resolve();
                        });
                    }
                });
                return loaded;
            };
            this.$scope = $scope;
            this.$q = $q;
            this.$http = $http;
            this.setService = SetService;
            this.parameterService = ParameterService;
            this.variableService = VariableService;
            this.objectiveFunctionService = ObjectiveFunctionService;
            this.constraintGroupService = ConstraintGroupService;
            this.constraintService = ConstraintService;
            this.modelService = ModelService;
            this.setDataService = SetDataService;
            this.parameterDataService = ParameterDataService;
            this.zip = new JSZip();
            this.scenarioId = scenario.id;
            this.modelId = scenario.modelId;
            $q.when(this.loadExecutable().promise).then(function () {
                $q.when(_this.loadModel().promise).then(function () {
                    $q.when(_this.loadData().promise).then(function () {
                        try {
                            var blob = _this.zip.generate({ type: 'blob' });
                            saveAs(blob, scenario.name + ".zip");
                            setTimeout($modalInstance.close, 1000);
                        }
                        catch (e) {
                            console.log(e);
                        }
                    });
                });
            });
        }
        return ExecutableRenderingController;
    }());
    exports.ExecutableRenderingController = ExecutableRenderingController;
});
//# sourceMappingURL=executableRenderingControllers.js.map