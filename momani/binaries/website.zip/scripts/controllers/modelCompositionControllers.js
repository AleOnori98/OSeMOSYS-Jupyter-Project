define(["require", "exports", "models/model", "services/setService", "services/parameterService", "services/variableService", "services/objectiveFunctionService", "services/constraintService", "services/constraintGroupService", "services/modelService"], function (require, exports, modelModel, setService, parameterService, variableService, objectiveFunctionService, constraintService, constraintGroupService, modelService) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [setService, parameterService, variableService, objectiveFunctionService, constraintGroupService, constraintService, modelService];
    var ModelCompositionController = (function () {
        function ModelCompositionController($scope, $routeParams, $window, $q, SetService, ParameterService, VariableService, ObjectiveFunctionService, ConstraintGroupService, ConstraintService, ModelService) {
            $scope.loading = true;
            var setReq = SetService.query().$promise;
            var parameterReq = ParameterService.query().$promise;
            var variableReq = VariableService.query().$promise;
            var objectiveFunctionReq = ObjectiveFunctionService.query().$promise;
            var constraintGroupReq = ConstraintGroupService.query().$promise;
            var constraintReq = ConstraintService.query().$promise;
            var modelReq;
            if ($routeParams['id'] === 'new') {
                var deferred = $q.defer();
                modelReq = deferred.promise;
                deferred.resolve(null);
            }
            else {
                modelReq = ModelService.get({ id: $routeParams['id'] }).$promise;
            }
            $q.all([setReq, parameterReq, variableReq, objectiveFunctionReq, constraintGroupReq, constraintReq, modelReq]).then(function (res) {
                $scope.model = new modelModel.Model(res[0], res[1], res[2], res[3], res[4], res[5], res[6]);
            }).finally(function () {
                $scope.loading = false;
            });
            $scope.save = function () {
                if ($scope.detailsForm.$invalid)
                    return;
                $scope.loading = true;
                ModelService.save($scope.model.serialize()).$promise.then(function () {
                    $window.location.href = '#/models';
                }).catch(function () {
                    alert('An error occured');
                }).finally(function () {
                    $scope.loading = false;
                });
            };
        }
        return ModelCompositionController;
    }());
    exports.ModelCompositionController = ModelCompositionController;
});
//# sourceMappingURL=modelCompositionControllers.js.map