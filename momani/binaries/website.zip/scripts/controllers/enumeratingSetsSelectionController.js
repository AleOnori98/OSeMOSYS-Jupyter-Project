define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var EnumeratingSetSelectionModalController = (function () {
        function EnumeratingSetSelectionModalController($scope, $modalInstance) {
            $scope.ok = function () {
                $modalInstance.close();
            };
            $scope.cancel = function () {
                $modalInstance.dismiss('cancel');
            };
        }
        return EnumeratingSetSelectionModalController;
    }());
    exports.EnumeratingSetSelectionModalController = EnumeratingSetSelectionModalController;
});
//# sourceMappingURL=enumeratingSetsSelectionController.js.map