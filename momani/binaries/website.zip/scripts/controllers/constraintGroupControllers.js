define(["require", "exports", "models/constraintGroup", "services/constraintGroupService"], function (require, exports, constraintGroupModel, constraintGroupService) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [constraintGroupService];
    var ConstraintGroupDetailsController = (function () {
        function ConstraintGroupDetailsController($scope, $routeParams, $window, $modal, $q, ConstraintGroupService) {
            $scope.loading = true;
            var constraintGroupReq;
            if ($routeParams['id'] === 'new') {
                var deferred = $q.defer();
                constraintGroupReq = deferred.promise;
                deferred.resolve(null);
            }
            else {
                constraintGroupReq = ConstraintGroupService.get({ id: $routeParams['id'] }).$promise;
            }
            $q.when(constraintGroupReq).then(function (data) {
                $scope.constraintGroup = new constraintGroupModel.ConstraintGroup(data);
                $scope.loading = false;
            });
            $scope.save = function () {
                if ($scope.detailsForm.$invalid)
                    return;
                $scope.loading = true;
                ConstraintGroupService.save($scope.constraintGroup.serialize(), function () {
                    $window.location.href = '#/constraints';
                }, function () {
                    alert('An error occured');
                    $scope.loading = false;
                });
            };
        }
        return ConstraintGroupDetailsController;
    }());
    exports.ConstraintGroupDetailsController = ConstraintGroupDetailsController;
});
//# sourceMappingURL=constraintGroupControllers.js.map