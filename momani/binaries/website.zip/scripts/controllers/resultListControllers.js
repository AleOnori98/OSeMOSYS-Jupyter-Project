define(["require", "exports", "services/modelService", "services/scenarioService"], function (require, exports, modelService, scenarioService) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [modelService, scenarioService];
    var ResultsModelListController = (function () {
        function ResultsModelListController($scope, $q, $http, ModelService) {
            $scope.loading = true;
            $scope.models = ModelService.query();
            $scope.models.$promise.finally(function () {
                $scope.loading = false;
            });
            $scope.orderProp = 'name';
        }
        return ResultsModelListController;
    }());
    exports.ResultsModelListController = ResultsModelListController;
    var ResultsScenarioListController = (function () {
        function ResultsScenarioListController($scope, $routeParams, ScenarioService) {
            $scope.loading = true;
            $scope.scenarios = ScenarioService.query({ modelId: $routeParams['modelId'] });
            $scope.scenarios.$promise.finally(function () {
                $scope.loading = false;
            });
            $scope.orderProp = 'revision';
        }
        return ResultsScenarioListController;
    }());
    exports.ResultsScenarioListController = ResultsScenarioListController;
});
//# sourceMappingURL=resultListControllers.js.map