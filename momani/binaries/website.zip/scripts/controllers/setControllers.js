define(["require", "exports", "models/set", "services/setService", "filters/checkmarkFilter"], function (require, exports, setModel, setService, checkmarkFilter) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var forceLoad = [checkmarkFilter, setService];
    var SetListController = (function () {
        function SetListController($scope, SetService) {
            $scope.loading = true;
            $scope.sets = SetService.query();
            $scope.sets.$promise.finally(function () {
                $scope.loading = false;
            });
            $scope.orderProp = 'name';
        }
        return SetListController;
    }());
    exports.SetListController = SetListController;
    var SetDetailsController = (function () {
        function SetDetailsController($scope, $routeParams, $window, $q, SetService) {
            $scope.loading = true;
            var setReq;
            if ($routeParams['id'] === 'new') {
                var deferred = $q.defer();
                setReq = deferred.promise;
                deferred.resolve(null);
            }
            else {
                setReq = SetService.get({ id: $routeParams['id'] }).$promise;
            }
            $q.all([setReq]).then(function (res) {
                $scope.set = new setModel.Set(res[0]);
                $scope.loading = false;
            });
            $scope.save = function () {
                if ($scope.detailsForm.$invalid)
                    return;
                $scope.loading = true;
                SetService.save($scope.set.serialize(), function () {
                    $window.location.href = '#/sets';
                }, function () {
                    alert('An error occured');
                    $scope.loading = false;
                });
            };
        }
        return SetDetailsController;
    }());
    exports.SetDetailsController = SetDetailsController;
});
//# sourceMappingURL=setControllers.js.map