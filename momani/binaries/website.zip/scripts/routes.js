define(["require", "exports", "application", "controllers/setControllers", "controllers/parameterControllers", "controllers/variableControllers", "controllers/objectiveFunctionControllers", "controllers/constraintGroupControllers", "controllers/constraintControllers", "controllers/modelListControllers", "controllers/modelCompositionControllers", "controllers/modelDataControllers", "controllers/scenarioControllers", "controllers/setDataControllers", "controllers/parameterDataControllers", "controllers/resultListControllers", "controllers/variableResultControllers", "controllers/compareResultsControllers"], function (require, exports, application, setControllers, parameterControllers, variableControllers, objectiveFunctionControllers, constraintGroupControllers, constraintControllers, modelListControllers, modelCompositionControllers, modelDataController, scenarioControllers, setDataControllers, parameterDataControllers, resultListControllers, variableResultControllers, compareResultsControllers) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    application.config(function ($routeProvider, $rootScopeProvider) {
        $rootScopeProvider.digestTtl(100);
        $routeProvider
            .when('/sets', {
            controller: setControllers.SetListController,
            templateUrl: 'partials/set-list.html',
        })
            .when('/sets/:id', {
            controller: setControllers.SetDetailsController,
            templateUrl: 'partials/set-detail.html'
        })
            .when('/parameters', {
            controller: parameterControllers.ParameterListController,
            templateUrl: 'partials/parameter-list.html'
        })
            .when('/parameters/:id', {
            controller: parameterControllers.ParameterDetailsController,
            templateUrl: 'partials/parameter-detail.html'
        })
            .when('/variables', {
            controller: variableControllers.VariableListController,
            templateUrl: 'partials/variable-list.html'
        })
            .when('/variables/:id', {
            controller: variableControllers.VariableDetailsController,
            templateUrl: 'partials/variable-detail.html'
        })
            .when('/functions', {
            controller: objectiveFunctionControllers.ObjectiveFunctionListController,
            templateUrl: 'partials/function-list.html'
        })
            .when('/functions/:id', {
            controller: objectiveFunctionControllers.ObjectiveFunctionDetailsController,
            templateUrl: 'partials/function-detail.html'
        })
            .when('/constraintGroups/:id', {
            controller: constraintGroupControllers.ConstraintGroupDetailsController,
            templateUrl: 'partials/constraint-group-detail.html'
        })
            .when('/constraints', {
            controller: constraintControllers.ConstraintListController,
            templateUrl: 'partials/constraint-list.html'
        })
            .when('/constraints/:id', {
            controller: constraintControllers.ConstraintDetailsController,
            templateUrl: 'partials/constraint-detail.html'
        })
            .when('/models', {
            controller: modelListControllers.ModelListController,
            templateUrl: 'partials/model-list.html'
        })
            .when('/models/:id/compose', {
            controller: modelCompositionControllers.ModelCompositionController,
            templateUrl: 'partials/composition-details.html'
        })
            .when('/models/:id/setData', {
            controller: modelDataController.ModelDataController,
            templateUrl: 'partials/set-data-list.html'
        })
            .when('/models/:modelId/setData/:setId', {
            controller: setDataControllers.SetDataController,
            templateUrl: 'partials/set-data.html'
        })
            .when('/models/:modelId/scenarios', {
            controller: scenarioControllers.ScenarioListController,
            templateUrl: 'partials/scenario-list.html'
        })
            .when('/models/:modelId/:scenarioId/data', {
            controller: scenarioControllers.ScenarioDetailsController,
            templateUrl: 'partials/scenario-details.html'
        })
            .when('/models/:modelId/:scenarioId/data/sets/:setId?', {
            controller: scenarioControllers.SetListController,
            templateUrl: 'partials/scenario-set-list.html'
        })
            .when('/models/:modelId/:scenarioId/data/parameter/:parameterId', {
            controller: parameterDataControllers.ParameterDataController,
            templateUrl: 'partials/parameter-data.html'
        })
            .when('/models/:modelId/:scenarioId/data/parameter/:parameterId/fromSet/:setId?', {
            controller: parameterDataControllers.ParameterDataController,
            templateUrl: 'partials/parameter-data.html'
        })
            .when('/models/:modelId/:scenarioId/data/csv', {
            controller: parameterDataControllers.CsvParameterDataController,
            templateUrl: 'partials/parameter-data-csv.html'
        })
            .when('/models/:modelId/:scenarioId/data/csv/:filterType/:filteredItemId/:filterValue?', {
            controller: parameterDataControllers.CsvParameterDataController,
            templateUrl: 'partials/parameter-data-csv.html'
        })
            .when('/models/:modelId/:scenarioId/data/:filterType/:filteredItemId/:filterValue', {
            controller: parameterDataControllers.CsvParameterDataController,
            templateUrl: 'partials/parameter-data-csv.html'
        })
            .when('/models/:modelId/:scenarioId/data/:filterType/:filteredItemId/csv', {
            controller: parameterDataControllers.CsvParameterDataController,
            templateUrl: 'partials/parameter-data-csv.html'
        })
            .when('/results', {
            controller: resultListControllers.ResultsModelListController,
            templateUrl: 'partials/result-model-list.html'
        })
            .when('/results/:modelId/scenarios', {
            controller: resultListControllers.ResultsScenarioListController,
            templateUrl: 'partials/result-scenario-list.html'
        })
            .when('/results/:modelId/:scenarioId/variables', {
            controller: variableResultControllers.VariableResultListController,
            templateUrl: 'partials/variable-result-list.html'
        })
            .when('/results/:modelId/:scenarioId/:variableId/charts', {
            controller: variableResultControllers.VariableResultChartsController,
            templateUrl: 'partials/variable-result-charts.html'
        })
            .when('/results/:modelId/:scenarioId/data/allVariables', {
            controller: variableResultControllers.CsvVariableResultController,
            templateUrl: 'partials/variable-result-csv.html'
        })
            .when('/results/:modelId/compare', {
            controller: compareResultsControllers.CompareResultsController,
            templateUrl: 'partials/compare-results.html'
        })
            .otherwise({
            redirectTo: '/models'
        });
    });
});
//# sourceMappingURL=routes.js.map