define(["require", "exports", "application"], function (require, exports, application) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    application.filter('checkmark', function () { return function (input) { return (input ? "\u2713" : "\u2718"); }; });
});
//# sourceMappingURL=checkmarkFilter.js.map