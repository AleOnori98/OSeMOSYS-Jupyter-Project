define(["require", "exports", "appSettings"], function (require, exports, settings) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var apiRoot = settings.get('api');
    exports.baseUrl = apiRoot;
    exports.sets = apiRoot + 'Sets/';
    exports.parameters = apiRoot + 'Parameters/';
    exports.variables = apiRoot + 'Variables/';
    exports.objectiveFunctions = apiRoot + 'ObjectiveFunctions/';
    exports.constraintGroups = apiRoot + 'ConstraintGroups/';
    exports.constraints = apiRoot + 'Constraints/';
    exports.models = apiRoot + 'ComposedModels/';
    exports.modelCloning = apiRoot + 'ModelCloning/';
    exports.scenarios = apiRoot + 'Scenarios/';
    exports.scenarioCloning = apiRoot + 'ScenarioCloning/';
    exports.setData = apiRoot + 'SetData/';
    exports.parameterData = apiRoot + 'ParameterData/';
    exports.parameterDataForSet = apiRoot + 'ParameterDataForSet/';
    exports.parameterDataSlice = apiRoot + 'ParameterDataSlice/';
    exports.executable = apiRoot + 'Executable/';
    exports.variableResults = apiRoot + 'VariableResults/';
});
//# sourceMappingURL=urls.js.map