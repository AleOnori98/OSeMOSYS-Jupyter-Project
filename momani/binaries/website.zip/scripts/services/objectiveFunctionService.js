define(["require", "exports", "application", "urls"], function (require, exports, application, urls) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    application.factory('ObjectiveFunctionService', function ($resource) { return $resource(urls.objectiveFunctions + ':id', { id: '@id' }); });
});
//# sourceMappingURL=objectiveFunctionService.js.map