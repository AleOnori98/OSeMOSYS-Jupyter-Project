define(["require", "exports", "application", "urls"], function (require, exports, application, urls) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    application.factory('ModelService', function ($resource) { return $resource(urls.models + ':id', { id: '@id' }); });
});
//# sourceMappingURL=modelService.js.map