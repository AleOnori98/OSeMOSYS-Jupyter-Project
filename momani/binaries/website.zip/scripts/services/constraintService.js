define(["require", "exports", "application", "urls"], function (require, exports, application, urls) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    application.factory('ConstraintService', function ($resource) { return $resource(urls.constraints + ':id', { id: '@id' }); });
});
//# sourceMappingURL=constraintService.js.map