define(["require", "exports", "application", "urls"], function (require, exports, application, urls) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    application.factory('ScenarioService', function ($resource) { return $resource(urls.scenarios + ':id', { id: '@id' }); });
});
//# sourceMappingURL=scenarioService.js.map