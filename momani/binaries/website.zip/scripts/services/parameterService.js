define(["require", "exports", "application", "urls"], function (require, exports, application, urls) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    application.factory('ParameterService', function ($resource) { return $resource(urls.parameters + ':id', { id: '@id' }); });
});
//# sourceMappingURL=parameterService.js.map