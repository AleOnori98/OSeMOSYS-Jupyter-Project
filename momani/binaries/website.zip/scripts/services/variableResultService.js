define(["require", "exports", "application", "urls"], function (require, exports, application, urls) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    application.factory('VariableResultService', function ($resource) { return $resource(urls.variableResults); });
});
//# sourceMappingURL=variableResultService.js.map