define(["require", "exports", "application", "urls"], function (require, exports, application, urls) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    application.factory('ParameterDataService', function ($resource) { return $resource(urls.parameterData + '?parameterId=:parameterId&modelId=:modelId', { parameterId: '@parameterId', modelId: '@modelId' }); });
});
//# sourceMappingURL=parameterDataService.js.map