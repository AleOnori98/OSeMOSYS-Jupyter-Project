define(["require", "exports", "application", "urls"], function (require, exports, application, urls) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    application.factory('SetService', function ($resource) { return $resource(urls.sets + ':id', { id: '@id' }); });
});
//# sourceMappingURL=setService.js.map