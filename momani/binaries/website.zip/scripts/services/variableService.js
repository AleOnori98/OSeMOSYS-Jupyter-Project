define(["require", "exports", "application", "urls"], function (require, exports, application, urls) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    application.factory('VariableService', function ($resource) { return $resource(urls.variables + ':id', { id: '@id' }); });
});
//# sourceMappingURL=variableService.js.map