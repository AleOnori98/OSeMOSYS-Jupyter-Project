define(["require", "exports", "application", "urls"], function (require, exports, application, urls) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    application.factory('SetDataService', function ($resource) { return $resource(urls.setData); });
});
//# sourceMappingURL=setDataService.js.map