define(["require", "exports", "application", "urls"], function (require, exports, application, urls) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    application.factory('ConstraintGroupService', function ($resource) { return $resource(urls.constraintGroups + ':id', { id: '@id' }); });
});
//# sourceMappingURL=constraintGroupService.js.map