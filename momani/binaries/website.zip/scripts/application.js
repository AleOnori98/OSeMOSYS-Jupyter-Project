define(["require", "exports", "angular"], function (require, exports, angular) {
    "use strict";
    var application = angular.module('application', ['ngRoute', 'ngResource', 'ui.bootstrap', 'mgcrea.ngStrap.navbar', 'checklist-model', 'ngHandsontable', 'nvd3', 'angular-confirm', 'treeGrid', 'angularSpinner', 'color.picker', 'angularEnter']);
    application.config(['usSpinnerConfigProvider', function (usSpinnerConfigProvider) {
            usSpinnerConfigProvider.setDefaults({ radius: 30, width: 8, length: 16 });
        }]);
    return application;
});
//# sourceMappingURL=application.js.map