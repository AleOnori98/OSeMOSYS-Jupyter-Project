var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
define(["require", "exports", "lodash", "models/equationObjectSet", "models/modelDependency", "controllers/equationObjectEditSetsController", "controllers/equationObjectModalControllers", "controllers/selectEnumeratorModalControllers"], function (require, exports, _, equationObjectSet, modelDependency, equationObjectEditSetsController, equationObjectModalControllers, selectEnumeratorModalControllers) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var ReplaceGroupOption;
    (function (ReplaceGroupOption) {
        ReplaceGroupOption[ReplaceGroupOption["Sets"] = 0] = "Sets";
        ReplaceGroupOption[ReplaceGroupOption["Parameters"] = 1] = "Parameters";
        ReplaceGroupOption[ReplaceGroupOption["Variables"] = 2] = "Variables";
        ReplaceGroupOption[ReplaceGroupOption["Operators"] = 3] = "Operators";
        ReplaceGroupOption[ReplaceGroupOption["Number"] = 4] = "Number";
    })(ReplaceGroupOption = exports.ReplaceGroupOption || (exports.ReplaceGroupOption = {}));
    exports.availableGroupOptions = {
        all: [ReplaceGroupOption.Sets, ReplaceGroupOption.Parameters, ReplaceGroupOption.Variables, ReplaceGroupOption.Operators, ReplaceGroupOption.Number],
        sets: [ReplaceGroupOption.Sets],
        none: [],
    };
    exports.equationOperators = [
        { id: '=', name: '=' },
        { id: '>', name: '>' },
        { id: '<', name: '<' },
        { id: '>=', name: '>=' },
        { id: '<=', name: '<=' },
        { id: '<>', name: '<>' },
        { id: '+', name: '+' },
        { id: '-', name: '-' },
        { id: '*', name: '*' },
        { id: '/', name: '/' },
        { id: '()', name: '( )' },
        { id: 'sum', name: 'Sum' },
        { id: 'min', name: 'Min' },
        { id: 'max', name: 'Max' },
        { id: 'ifthen', name: 'If - then' },
        { id: 'if', name: 'If - then - else' },
    ];
    exports.modalReplaceHandler = function (availableGroups, callback, modal, data, updateHandler) {
        var modalInstance = modal.open({
            templateUrl: 'partials/replace-equation-object.html',
            controller: equationObjectModalControllers.EquationObjectModalController,
            resolve: {
                data: function () { return data; },
                availableGroups: function () { return availableGroups; },
            }
        });
        modalInstance.result.then(function (selectedItem) {
            callback(selectedItem);
            if (updateHandler)
                updateHandler();
        });
    };
    var EquationObjectAction = (function () {
        function EquationObjectAction(text, handler) {
            this.text = text;
            this.handler = handler;
        }
        return EquationObjectAction;
    }());
    exports.EquationObjectAction = EquationObjectAction;
    var EquationObjectBase = (function () {
        function EquationObjectBase(data, availableReplacementGroups, replaceCallback, modal, updateHandler) {
            var _this = this;
            this.operator1 = null;
            this.operator2 = null;
            this.operator3 = null;
            this.innerEquation1 = null;
            this.innerEquation2 = null;
            this.innerEquation3 = null;
            this.innerEquation1AvailableGroups = exports.availableGroupOptions.all;
            this.innerEquation2AvailableGroups = exports.availableGroupOptions.all;
            this.innerEquation3AvailableGroups = exports.availableGroupOptions.all;
            this.actions = [];
            this.canRender = false;
            this.render = function () { return ''; };
            this.replaceInnerEquation1 = function (equation) {
                _this.innerEquation1 = createEquationObject(_this.data, _this.innerEquation1AvailableGroups, _this.replaceInnerEquation1, _this.modal, equation, _this.updateHandler);
            };
            this.replaceInnerEquation2 = function (equation) {
                _this.innerEquation2 = createEquationObject(_this.data, _this.innerEquation2AvailableGroups, _this.replaceInnerEquation2, _this.modal, equation, _this.updateHandler);
            };
            this.replaceInnerEquation3 = function (equation) {
                _this.innerEquation3 = createEquationObject(_this.data, _this.innerEquation3AvailableGroups, _this.replaceInnerEquation3, _this.modal, equation, _this.updateHandler);
            };
            this.getSets = function () {
                var setCollection = [];
                if (_this.innerEquation1) {
                    setCollection = setCollection.concat(_this.innerEquation1.getSets());
                }
                if (_this.innerEquation2) {
                    setCollection = setCollection.concat(_this.innerEquation2.getSets());
                }
                if (_this.innerEquation3) {
                    setCollection = setCollection.concat(_this.innerEquation3.getSets());
                }
                return _.uniqBy(setCollection, function (setItem) {
                    return [setItem.setId, setItem.actualAbbreviation].join(':');
                });
            };
            this.getDependencies = function () {
                var dependencies = new modelDependency.ModelDependency([], [], []);
                if (_this.innerEquation1) {
                    dependencies = dependencies.join(_this.innerEquation1.getDependencies());
                }
                if (_this.innerEquation2) {
                    dependencies = dependencies.join(_this.innerEquation2.getDependencies());
                }
                if (_this.innerEquation3) {
                    dependencies = dependencies.join(_this.innerEquation3.getDependencies());
                }
                return dependencies;
            };
            this.data = data;
            this.updateHandler = updateHandler;
            this.actions.push(new EquationObjectAction('Replace', function () { exports.modalReplaceHandler(availableReplacementGroups, replaceCallback, modal, data, updateHandler); }));
            this.modal = modal;
        }
        return EquationObjectBase;
    }());
    exports.EquationObjectBase = EquationObjectBase;
    function createEquationObject(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler) {
        if (equation == null)
            return new EmptyEquationObject(data, availableReplacementGroups, replaceCallback, modal, updateHandler);
        switch (equation.type) {
            case 'Empty':
                return new EmptyEquationObject(data, availableReplacementGroups, replaceCallback, modal, updateHandler);
            case 'Number':
                return new NumberEquationObject(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler);
            case 'Parameter':
                return new ParameterEquationObject(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler);
            case 'Variable':
                return new VariableEquationObject(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler);
            case 'Operator':
                return createOperatorEquationObject(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler);
            case 'Set':
                return new SetEquationObject(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler);
            default:
                return new EmptyEquationObject(data, availableReplacementGroups, replaceCallback, modal, updateHandler);
        }
    }
    exports.createEquationObject = createEquationObject;
    var EmptyEquationObject = (function (_super) {
        __extends(EmptyEquationObject, _super);
        function EmptyEquationObject(data, availableReplacementGroups, replaceCallback, modal, updateHandler) {
            var _this = _super.call(this, data, availableReplacementGroups, replaceCallback, modal, updateHandler) || this;
            _this.serialize = function () {
                return {
                    type: 'Empty',
                    value: null,
                    innerEquation1: null,
                    innerEquation2: null,
                    innerEquation3: null,
                    setChanges: null,
                    enumeratingSets: null,
                };
            };
            _this.asString = function () { return 'null'; };
            _this.render = function () { return '...'; };
            _this.canRender = true;
            return _this;
        }
        return EmptyEquationObject;
    }(EquationObjectBase));
    exports.EmptyEquationObject = EmptyEquationObject;
    var NumberEquationObject = (function (_super) {
        __extends(NumberEquationObject, _super);
        function NumberEquationObject(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler) {
            var _this = _super.call(this, data, availableReplacementGroups, replaceCallback, modal, updateHandler) || this;
            _this.serialize = function () {
                return {
                    type: 'Number',
                    value: _this.value.toString(),
                    innerEquation1: null,
                    innerEquation2: null,
                    innerEquation3: null,
                    setChanges: null,
                    enumeratingSets: null,
                };
            };
            _this.asString = function () { return _this.value.toString(); };
            _this.value = +equation.value;
            _this.render = function () { return _this.value.toString(); };
            _this.canRender = true;
            return _this;
        }
        return NumberEquationObject;
    }(EquationObjectBase));
    var EditableSetEquationObjectBase = (function (_super) {
        __extends(EditableSetEquationObjectBase, _super);
        function EditableSetEquationObjectBase(data, availableReplacementGroups, replaceCallback, modal, updateHandler) {
            var _this = _super.call(this, data, availableReplacementGroups, replaceCallback, modal, updateHandler) || this;
            _this.getSets = function () {
                return _.uniqBy(_this.internalSets, function (setItem) {
                    return [setItem.setId, setItem.actualAbbreviation].join(':');
                });
            };
            _this.asString = function () { return _this.render(); };
            var editHandler = function () {
                var internalSets = _this.internalSets;
                var modalInstance = modal.open({
                    templateUrl: 'partials/equation-object-edit-sets.html',
                    controller: equationObjectEditSetsController.EquationObjectModalController,
                    resolve: {
                        sets: function () { return internalSets; },
                    }
                });
                modalInstance.result.then(function (setChanges) {
                    _.forEach(_this.internalSets, function (internalSet, index) {
                        internalSet.applyChanges(setChanges[index]);
                    });
                    if (_this.updateHandler)
                        _this.updateHandler();
                });
            };
            _this.actions.push(new EquationObjectAction('Edit sets', editHandler));
            return _this;
        }
        return EditableSetEquationObjectBase;
    }(EquationObjectBase));
    var ParameterEquationObject = (function (_super) {
        __extends(ParameterEquationObject, _super);
        function ParameterEquationObject(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler) {
            var _this = _super.call(this, data, availableReplacementGroups, replaceCallback, modal, updateHandler) || this;
            _this.serialize = function () {
                return {
                    type: 'Parameter',
                    value: _this.parameter.id,
                    innerEquation1: null,
                    innerEquation2: null,
                    innerEquation3: null,
                    setChanges: _.map(_this.internalSets, function (internalSet) { return internalSet.getChanges(); }),
                    enumeratingSets: null,
                };
            };
            _this.getDependencies = function () {
                return new modelDependency.ModelDependency(_this.parameter.sets, [_this.parameter.id], []);
            };
            _this.parameter = _.find(data.parameters, function (p) { return p.id == equation.value; });
            var parameterSets = _.map(_this.parameter.sets, function (setId) { return _.find(data.sets, function (s) { return s.id == setId; }); });
            _this.internalSets = _.map(parameterSets, function (set, index) {
                var previousSets = _.take(parameterSets, index);
                var repetitions = _.filter(previousSets, function (previousSet) { return previousSet.id === set.id; }).length;
                var item = new equationObjectSet.EquationObjectSet(set, repetitions + 1);
                if (equation.setChanges) {
                    item.applyChanges(equation.setChanges[index]);
                }
                return item;
            });
            _this.render = function () {
                var internalSetsString = _this.internalSets.length > 0 ? " [" + _.map(_this.internalSets, function (is) { return is.render(); }).join(', ') + "]" : "";
                return "" + _this.parameter.name + internalSetsString;
            };
            _this.canRender = true;
            return _this;
        }
        return ParameterEquationObject;
    }(EditableSetEquationObjectBase));
    var VariableEquationObject = (function (_super) {
        __extends(VariableEquationObject, _super);
        function VariableEquationObject(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler) {
            var _this = _super.call(this, data, availableReplacementGroups, replaceCallback, modal, updateHandler) || this;
            _this.serialize = function () {
                return {
                    type: 'Variable',
                    value: _this.variable.id,
                    innerEquation1: null,
                    innerEquation2: null,
                    innerEquation3: null,
                    setChanges: _.map(_this.internalSets, function (internalSet) { return internalSet.getChanges(); }),
                    enumeratingSets: null,
                };
            };
            _this.getDependencies = function () {
                return new modelDependency.ModelDependency(_this.variable.sets, [], [_this.variable.id]);
            };
            _this.variable = _.find(data.variables, function (v) { return v.id == equation.value; });
            var variableSets = _.map(_this.variable.sets, function (setId) { return _.find(data.sets, function (s) { return s.id == setId; }); });
            _this.internalSets = _.map(variableSets, function (set, index) {
                var previousSets = _.take(variableSets, index);
                var repetitions = _.filter(previousSets, function (previousSet) { return previousSet.id === set.id; }).length;
                var item = new equationObjectSet.EquationObjectSet(set, repetitions + 1);
                if (equation.setChanges) {
                    item.applyChanges(equation.setChanges[index]);
                }
                return item;
            });
            _this.render = function () {
                var internalSetsString = _this.internalSets.length > 0 ? " [" + _.map(_this.internalSets, function (is) { return is.render(); }).join(', ') + "]" : "";
                return "" + _this.variable.name + internalSetsString;
            };
            _this.canRender = true;
            return _this;
        }
        return VariableEquationObject;
    }(EditableSetEquationObjectBase));
    var SetEquationObject = (function (_super) {
        __extends(SetEquationObject, _super);
        function SetEquationObject(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler) {
            var _this = _super.call(this, data, availableReplacementGroups, replaceCallback, modal, updateHandler) || this;
            _this.getSets = function () {
                return [_this.internalSet];
            };
            _this.serialize = function () {
                return {
                    type: 'Set',
                    value: _this.set.id,
                    innerEquation1: null,
                    innerEquation2: null,
                    innerEquation3: null,
                    setChanges: [_this.internalSet.getChanges()],
                    enumeratingSets: null,
                };
            };
            _this.asString = function () { return _this.render(); };
            _this.getDependencies = function () {
                return new modelDependency.ModelDependency([_this.set.id], [], []);
            };
            _this.set = _.find(data.sets, function (s) { return s.id == equation.value; });
            _this.render = function () { return _this.internalSet.render(); };
            _this.canRender = true;
            _this.internalSet = new equationObjectSet.EquationObjectSet(_this.set, 1);
            if (equation.setChanges) {
                _this.internalSet.applyChanges(equation.setChanges[0]);
            }
            var editHandler = function () {
                var internalSets = [_this.internalSet];
                var modalInstance = modal.open({
                    templateUrl: 'partials/equation-object-edit-sets.html',
                    controller: equationObjectEditSetsController.EquationObjectModalController,
                    resolve: {
                        sets: function () { return internalSets; },
                    }
                });
                modalInstance.result.then(function (setChanges) {
                    _this.internalSet.applyChanges(setChanges[0]);
                    if (_this.updateHandler)
                        _this.updateHandler();
                });
            };
            _this.actions.push(new EquationObjectAction('Edit set', editHandler));
            return _this;
        }
        return SetEquationObject;
    }(EquationObjectBase));
    var SimpleOperator = (function (_super) {
        __extends(SimpleOperator, _super);
        function SimpleOperator(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler) {
            var _this = _super.call(this, data, availableReplacementGroups, replaceCallback, modal, updateHandler) || this;
            _this.serialize = function () {
                return {
                    type: 'Operator',
                    value: _this.operator2,
                    innerEquation1: _this.innerEquation1.serialize(),
                    innerEquation2: _this.innerEquation2.serialize(),
                    innerEquation3: null,
                    setChanges: null,
                    enumeratingSets: null,
                };
            };
            _this.asString = function () { return _this.innerEquation1.asString() + " " + _this.operator2 + " " + _this.innerEquation2.asString(); };
            _this.operator2 = equation.value;
            _this.innerEquation1 = createEquationObject(data, _this.innerEquation1AvailableGroups, _this.replaceInnerEquation1, modal, equation.innerEquation1, updateHandler);
            _this.innerEquation2 = createEquationObject(data, _this.innerEquation2AvailableGroups, _this.replaceInnerEquation2, modal, equation.innerEquation2, updateHandler);
            return _this;
        }
        return SimpleOperator;
    }(EquationObjectBase));
    var ParenthesisOperator = (function (_super) {
        __extends(ParenthesisOperator, _super);
        function ParenthesisOperator(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler) {
            var _this = _super.call(this, data, availableReplacementGroups, replaceCallback, modal, updateHandler) || this;
            _this.serialize = function () {
                return {
                    type: 'Operator',
                    value: '()',
                    innerEquation1: _this.innerEquation1.serialize(),
                    innerEquation2: null,
                    innerEquation3: null,
                    setChanges: null,
                    enumeratingSets: null,
                };
            };
            _this.asString = function () { return "(" + _this.innerEquation1.asString() + ")"; };
            _this.operator1 = '(';
            _this.operator2 = ')';
            _this.innerEquation1 = createEquationObject(data, _this.innerEquation1AvailableGroups, _this.replaceInnerEquation1, modal, equation.innerEquation1, updateHandler);
            return _this;
        }
        return ParenthesisOperator;
    }(EquationObjectBase));
    var IfThenOperator = (function (_super) {
        __extends(IfThenOperator, _super);
        function IfThenOperator(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler) {
            var _this = _super.call(this, data, availableReplacementGroups, replaceCallback, modal, updateHandler) || this;
            _this.serialize = function () {
                return {
                    type: 'Operator',
                    value: 'ifthen',
                    innerEquation1: _this.innerEquation1.serialize(),
                    innerEquation2: _this.innerEquation2.serialize(),
                    innerEquation3: null,
                    setChanges: null,
                    enumeratingSets: null,
                };
            };
            _this.asString = function () { return "if " + _this.innerEquation1.asString() + " then " + _this.innerEquation2.asString(); };
            _this.operator1 = 'if';
            _this.operator2 = 'then';
            _this.innerEquation1 = createEquationObject(data, _this.innerEquation1AvailableGroups, _this.replaceInnerEquation1, modal, equation.innerEquation1, updateHandler);
            _this.innerEquation2 = createEquationObject(data, _this.innerEquation2AvailableGroups, _this.replaceInnerEquation2, modal, equation.innerEquation2, updateHandler);
            return _this;
        }
        return IfThenOperator;
    }(EquationObjectBase));
    var IfOperator = (function (_super) {
        __extends(IfOperator, _super);
        function IfOperator(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler) {
            var _this = _super.call(this, data, availableReplacementGroups, replaceCallback, modal, updateHandler) || this;
            _this.serialize = function () {
                return {
                    type: 'Operator',
                    value: 'if',
                    innerEquation1: _this.innerEquation1.serialize(),
                    innerEquation2: _this.innerEquation2.serialize(),
                    innerEquation3: _this.innerEquation3.serialize(),
                    setChanges: null,
                    enumeratingSets: null,
                };
            };
            _this.asString = function () { return "if " + _this.innerEquation1.asString() + " then " + _this.innerEquation2.asString() + " else " + _this.innerEquation3.asString(); };
            _this.operator1 = 'if';
            _this.operator2 = 'then';
            _this.operator3 = 'else';
            _this.innerEquation1 = createEquationObject(data, _this.innerEquation1AvailableGroups, _this.replaceInnerEquation1, modal, equation.innerEquation1, updateHandler);
            _this.innerEquation2 = createEquationObject(data, _this.innerEquation2AvailableGroups, _this.replaceInnerEquation2, modal, equation.innerEquation2, updateHandler);
            _this.innerEquation3 = createEquationObject(data, _this.innerEquation3AvailableGroups, _this.replaceInnerEquation3, modal, equation.innerEquation3, updateHandler);
            return _this;
        }
        return IfOperator;
    }(EquationObjectBase));
    var SetEnumeratedOperator = (function (_super) {
        __extends(SetEnumeratedOperator, _super);
        function SetEnumeratedOperator(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler) {
            var _this = _super.call(this, data, availableReplacementGroups, replaceCallback, modal, updateHandler) || this;
            _this.serialize = function () {
                return {
                    type: 'Operator',
                    value: _this.operatorValue,
                    innerEquation1: _this.innerEquation1.serialize(),
                    innerEquation2: _this.innerEquation2.serialize(),
                    innerEquation3: null,
                    setChanges: null,
                    enumeratingSets: null,
                };
            };
            _this.getSets = function () {
                return _.filter(_this.retrieveInternalSets(), function (internalSet) {
                    return !_.some(_this.innerEquation1.enumerators, function (enumerator) {
                        return enumerator.set.id == internalSet.setId && enumerator.abbreviation == internalSet.actualAbbreviation;
                    });
                });
            };
            _this.retrieveInternalSets = function () {
                var setCollection = [];
                setCollection = setCollection.concat(_this.innerEquation1.constraint.getSets());
                setCollection = setCollection.concat(_this.innerEquation2.getSets());
                return _.uniqBy(setCollection, function (setItem) {
                    return [setItem.setId, setItem.actualAbbreviation].join(':');
                });
            };
            _this.innerEquation2 = createEquationObject(data, _this.innerEquation2AvailableGroups, _this.replaceInnerEquation2, modal, equation.innerEquation2, updateHandler);
            _this.innerEquation1 = new SetEnumeratorObject(data, modal, _this.retrieveInternalSets, equation.innerEquation1, updateHandler);
            return _this;
        }
        return SetEnumeratedOperator;
    }(EquationObjectBase));
    var MinMaxOperator = (function (_super) {
        __extends(MinMaxOperator, _super);
        function MinMaxOperator(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler) {
            var _this = _super.call(this, data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler) || this;
            _this.asString = function () { return _this.operatorValue + "{" + _this.innerEquation1.asString() + "} " + _this.operatorValue + "(" + _this.innerEquation2.asString() + ")"; };
            _this.operatorValue = equation.value;
            _this.operator1 = equation.value + "{";
            _this.operator2 = "} " + equation.value + "(";
            _this.operator3 = ')';
            _this.innerEquation2AvailableGroups = exports.availableGroupOptions.sets;
            return _this;
        }
        return MinMaxOperator;
    }(SetEnumeratedOperator));
    var SumOperator = (function (_super) {
        __extends(SumOperator, _super);
        function SumOperator(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler) {
            var _this = _super.call(this, data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler) || this;
            _this.asString = function () { return "sum{" + _this.innerEquation1.asString() + "} " + _this.innerEquation2.asString(); };
            _this.operatorValue = 'sum';
            _this.operator1 = 'sum {';
            _this.operator2 = '}';
            return _this;
        }
        return SumOperator;
    }(SetEnumeratedOperator));
    var SetEnumeratorObject = (function () {
        function SetEnumeratorObject(data, modal, sets, equation, updateHandler) {
            var _this = this;
            this.actions = [];
            this.enumerators = [];
            this.render = function () {
                var render;
                if (_this.enumerators.length == 0) {
                    render = '...';
                }
                else {
                    render = _.map(_this.enumerators, function (enumerator) { return enumerator.render(); }).join(', ');
                }
                if (!(_this.constraint instanceof EmptyEquationObject)) {
                    render += ": " + _this.constraint.asString();
                }
                return render;
            };
            this.serialize = function () {
                return {
                    type: 'SetEnumerator',
                    value: null,
                    innerEquation1: _this.constraint ? _this.constraint.serialize() : null,
                    innerEquation2: null,
                    innerEquation3: null,
                    setChanges: null,
                    enumeratingSets: _.map(_this.enumerators, function (enumerator) { return enumerator.serialize(); }),
                };
            };
            this.asString = function () {
                var render;
                if (_this.enumerators.length == 0) {
                    render = 'null';
                }
                else {
                    render = _.map(_this.enumerators, function (enumerator) { return enumerator.render(); }).join(', ');
                }
                if (!(_this.constraint instanceof EmptyEquationObject)) {
                    render += ": " + _this.constraint.asString();
                }
                return render;
            };
            this.getDependencies = function () {
                return _this.constraint.getDependencies();
            };
            this.loadEnumerators = function (enumerators, constraint) {
                _this.enumerators = _.map(enumerators, function (enumerator) { return new EnumeratingSetObject(_this.data, _this.modal, enumerator); });
                _this.constraint = createEquationObject(_this.data, exports.availableGroupOptions.all, null, null, constraint);
                if (_this.updateHandler)
                    _this.updateHandler();
            };
            this.data = data;
            this.modal = modal;
            this.updateHandler = updateHandler;
            this.sets = sets;
            if (equation) {
                this.loadEnumerators(equation.enumeratingSets, equation.innerEquation1);
            }
            else {
                this.loadEnumerators([], null);
            }
            this.canRender = true;
            this.actions.push(new EquationObjectAction('Select sets', function () { modalSelectEnumeratorsHandler(modal, _this.loadEnumerators, data, _this.sets, _this.enumerators, _this.constraint.serialize()); }));
        }
        SetEnumeratorObject.prototype.getSets = function () { return []; };
        return SetEnumeratorObject;
    }());
    var EnumeratingSetObject = (function () {
        function EnumeratingSetObject(data, modal, enumerator) {
            var _this = this;
            this.render = function () {
                return _this.abbreviation + " in " + _this.set.name;
            };
            this.serialize = function () {
                return {
                    setId: _this.set.id,
                    abbreviation: _this.abbreviation,
                };
            };
            this.data = data;
            this.modal = modal;
            this.abbreviation = enumerator.abbreviation;
            this.set = _.find(data.sets, function (s) { return s.id == enumerator.setId; });
        }
        return EnumeratingSetObject;
    }());
    function createOperatorEquationObject(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler) {
        switch (equation.value) {
            case '=':
            case '>':
            case '<':
            case '>=':
            case '<=':
            case '<>':
            case '+':
            case '-':
            case '*':
            case '/':
            case '^':
            case '&&':
            case '||':
                return new SimpleOperator(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler);
            case 'sum':
                return new SumOperator(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler);
            case '()':
                return new ParenthesisOperator(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler);
            case 'min':
            case 'max':
                return new MinMaxOperator(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler);
            case 'ifthen':
                return new IfThenOperator(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler);
            case 'if':
                return new IfOperator(data, availableReplacementGroups, replaceCallback, modal, equation, updateHandler);
            default:
                return new EmptyEquationObject(data, availableReplacementGroups, replaceCallback, modal, updateHandler);
        }
    }
    var modalSelectEnumeratorsHandler = function (modal, callback, data, sets, selected, constraint) {
        var modalInstance = modal.open({
            templateUrl: 'partials/select-enumerators.html',
            controller: selectEnumeratorModalControllers.SelectEnumeratorModalController,
            resolve: {
                data: function () { return data; },
                enumerators: function () { return sets(); },
                selected: function () { return selected; },
                constraint: function () { return constraint; },
            },
            size: 'lg',
        });
        modalInstance.result.then(function (result) {
            callback(result.enumerators, result.constraint);
        });
    };
});
//# sourceMappingURL=equationObject.js.map