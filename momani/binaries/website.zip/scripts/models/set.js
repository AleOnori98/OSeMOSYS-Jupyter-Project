define(["require", "exports", "node-uuid"], function (require, exports, uuid) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var Set = (function () {
        function Set(set) {
            var _this = this;
            this.serialize = function () {
                return {
                    id: _this.id,
                    name: _this.name,
                    abbreviation: _this.abbreviation,
                    description: _this.description,
                    numeric: _this.numeric,
                };
            };
            this.asModelString = function () {
                return "set " + _this.name + ";";
            };
            if (set) {
                this.id = set.id;
                this.name = set.name;
                this.abbreviation = set.abbreviation;
                this.description = set.description;
                this.numeric = set.numeric;
            }
            else {
                this.id = uuid.v4();
                this.name = '';
                this.abbreviation = '';
                this.description = '';
                this.numeric = false;
            }
        }
        return Set;
    }());
    exports.Set = Set;
});
//# sourceMappingURL=set.js.map