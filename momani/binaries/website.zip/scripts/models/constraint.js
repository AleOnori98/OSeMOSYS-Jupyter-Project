define(["require", "exports", "node-uuid", "models/equationObject"], function (require, exports, uuid, equationObject) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var Constraint = (function () {
        function Constraint(data, modal, constraintGroups, constraint) {
            var _this = this;
            this.serialize = function () {
                return {
                    id: _this.id,
                    constraintGroupId: _this.constraintGroupId,
                    name: _this.name,
                    description: _this.description,
                    equation: _this.equation.serialize(),
                    setConstraint: _this.hasSetConstraint ? _this.setConstraint.serialize() : null,
                };
            };
            this.replaceEquation = function (equation) {
                _this.equation = equationObject.createEquationObject(_this.data, equationObject.availableGroupOptions.all, _this.replaceEquation, _this.modal, equation, _this.updateEnumeratorsHandler);
                _this.updateEnumeratorsHandler();
            };
            this.replaceSetConstraint = function (equation) {
                _this.setConstraint = equationObject.createEquationObject(_this.data, equationObject.availableGroupOptions.all, _this.replaceSetConstraint, _this.modal, equation);
            };
            this.updateEnumeratorsHandler = function () {
                if (_this.loading)
                    return;
                _this.enumerators = _this.equation.getSets();
                _this.enumeratorListString = _.map(_this.enumerators, function (en) { return en.actualAbbreviation + " in " + en.name; }).join(', ');
            };
            this.getDependencies = function () {
                return _this.equation.getDependencies().join(_this.setConstraint.getDependencies());
            };
            this.asModelString = function () {
                var enumeratorStrings = _.map(_this.enumerators, function (e) {
                    return e.actualAbbreviation + " in " + e.name;
                });
                var setConstraintString = _this.hasSetConstraint ? ": " + _this.setConstraint.asString() : "";
                var enumerationString = _this.enumerators.length > 0 ? "{" + enumeratorStrings.join(', ') + setConstraintString + "}" : "";
                return "s.t. " + _this.name + enumerationString + ": " + _this.equation.asString() + ";";
            };
            this.data = data;
            this.modal = modal;
            var emptyGroup = [{ id: null, name: '', description: null }];
            this.constraintGroups = emptyGroup.concat(constraintGroups);
            this.loading = true;
            if (constraint) {
                this.id = constraint.id;
                this.constraintGroupId = constraint.constraintGroupId;
                this.name = constraint.name;
                this.description = constraint.description;
                this.equation = equationObject.createEquationObject(data, equationObject.availableGroupOptions.all, this.replaceEquation, modal, constraint.equation, this.updateEnumeratorsHandler);
                this.setConstraint = equationObject.createEquationObject(data, equationObject.availableGroupOptions.all, this.replaceSetConstraint, modal, constraint.setConstraint);
            }
            else {
                this.id = uuid.v4();
                this.constraintGroupId = null;
                this.name = '';
                this.description = '';
                this.equation = equationObject.createEquationObject(data, equationObject.availableGroupOptions.all, this.replaceEquation, modal, null, this.updateEnumeratorsHandler);
                this.setConstraint = equationObject.createEquationObject(data, equationObject.availableGroupOptions.all, this.replaceSetConstraint, modal);
            }
            this.hasSetConstraint = !(this.setConstraint instanceof equationObject.EmptyEquationObject);
            this.loading = false;
            this.updateEnumeratorsHandler();
        }
        return Constraint;
    }());
    exports.Constraint = Constraint;
});
//# sourceMappingURL=constraint.js.map