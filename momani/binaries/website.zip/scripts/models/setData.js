define(["require", "exports", "node-uuid"], function (require, exports, uuid) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var SetData = (function () {
        function SetData(modelId, set, setData) {
            var _this = this;
            this.serialize = function () {
                return {
                    setId: _this.setId,
                    modelId: _this.modelId,
                    items: _.map(_this.values, function (val) {
                        return {
                            name: val.name,
                            value: val.value.toString(),
                            color: val.color,
                            groupId: val.groupId,
                        };
                    }),
                    groups: _this.groups,
                };
            };
            this.valuesUnique = function () {
                return _this.values.length == _.uniqBy(_this.values, 'value').length;
            };
            this.addValue = function () {
                var colorNumber = Math.floor(Math.random() * 16777215).toString(16);
                var colorPad = '000000';
                var value = {
                    id: uuid.v4(),
                    value: null,
                    color: "#" + colorPad.substring(0, colorPad.length - colorNumber.length) + colorNumber,
                    groupId: null,
                    name: null,
                    editable: true,
                };
                if (_this.numeric) {
                    value.value = _this.values.length > 0 ? (+_.last(_this.values).value + 1) : 0;
                }
                else {
                    value.value = '';
                }
                _this.values.push(value);
            };
            this.removeValue = function (value) {
                _.remove(_this.values, value);
            };
            this.getValues = function () {
                return _.map(_this.values, function (val) { return val.value.toString(); });
            };
            this.getValueCount = function () {
                return _this.values.length;
            };
            this.getValueNamePairs = function () {
                return _.map(_this.values, function (val) {
                    return {
                        value: val.value.toString(),
                        name: val.name,
                    };
                });
            };
            this.addGroup = function () {
                _this.groups.push({
                    id: uuid.v4(),
                    name: '',
                });
            };
            this.removeGroup = function (group) {
                _.forEach(_this.values, function (val) {
                    if (val.groupId == group.id) {
                        val.groupId = null;
                    }
                    ;
                });
                _.remove(_this.groups, group);
            };
            this.getGlpkReadyValues = function () {
                return _.map(_this.values, function (val) {
                    var stringValue = val.value.toString();
                    return SetData.glpkReady(stringValue);
                });
            };
            this.setId = set.id;
            this.modelId = modelId;
            this.setName = set.name;
            this.description = set.description;
            this.numeric = set.numeric;
            this.values = setData && setData.items ? _.map(setData.items, function (i) {
                return {
                    id: uuid.v4(),
                    value: _this.numeric ? +i.value : i.value,
                    name: i.name,
                    color: i.color,
                    groupId: i.groupId,
                    editable: false,
                };
            }) : [];
            this.groups = setData && setData.groups ? setData.groups : [];
        }
        return SetData;
    }());
    SetData.glpkReady = function (value) {
        var regExp = new RegExp("^[a-zA-Z0-9_.]*$");
        if (value.match(regExp)) {
            return value;
        }
        return ("\"" + value + "\"");
    };
    exports.SetData = SetData;
});
//# sourceMappingURL=setData.js.map