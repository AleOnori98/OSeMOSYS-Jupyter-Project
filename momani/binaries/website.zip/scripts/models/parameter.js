define(["require", "exports", "lodash", "node-uuid"], function (require, exports, _, uuid) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var ParameterSet = (function () {
        function ParameterSet(value) {
            this.id = uuid.v4();
            this.value = value;
        }
        return ParameterSet;
    }());
    exports.ParameterSet = ParameterSet;
    var Parameter = (function () {
        function Parameter(setOptions, parameter) {
            var _this = this;
            this.addSet = function () {
                var firstSet = _.first(_this.setOptions);
                if (!firstSet)
                    return;
                _this.sets.push(new ParameterSet(firstSet.id));
            };
            this.removeSet = function (set) {
                _.remove(_this.sets, set);
            };
            this.render = function () {
                return '';
            };
            this.getInternalSets = function () {
                return _.map(_this.sets, function (variableSet, index) {
                    var set = _.find(_this.setOptions, function (so) { return so.id == variableSet.value; });
                    var sameSetCount = _(_this.sets).take(index).filter(function (s) { return s.value == set.id; }).value().length;
                    return {
                        set: set,
                        index: sameSetCount,
                        actualAbbreviation: Array(sameSetCount + 2).join(set.abbreviation),
                    };
                });
            };
            this.asModelString = function () {
                var setDefinitions = _.map(_this.getInternalSets(), function (internalSet) { return internalSet.actualAbbreviation + " in " + internalSet.set.name; });
                var internalSetDefinitionsString = _this.sets.length > 0 ? "{" + setDefinitions.join(', ') + "}" : "";
                return "param " + _this.name + internalSetDefinitionsString + ";";
            };
            this.setOptions = setOptions;
            if (parameter) {
                this.id = parameter.id;
                this.name = parameter.name;
                this.description = parameter.description;
                this.sets = _.map(parameter.sets, function (setId) {
                    return new ParameterSet(setId);
                });
                this.defaultValue = parameter.defaultValue;
                this.unit = parameter.unit;
            }
            else {
                this.id = uuid.v4();
                this.name = '';
                this.description = '';
                this.sets = [];
                this.defaultValue = 0;
                this.unit = '';
            }
        }
        Parameter.prototype.serialize = function () {
            return {
                id: this.id,
                name: this.name,
                description: this.description,
                sets: _.map(this.sets, function (set) { return set.value; }),
                defaultValue: this.defaultValue,
                unit: this.unit,
            };
        };
        return Parameter;
    }());
    exports.Parameter = Parameter;
});
//# sourceMappingURL=parameter.js.map