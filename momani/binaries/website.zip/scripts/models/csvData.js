var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
define(["require", "exports", "lodash", "models/setData"], function (require, exports, _, setDataModel) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var Dimension = (function () {
        function Dimension(setId, index, name, numeric, values) {
            this.setId = setId;
            this.index = index;
            this.name = name;
            this.numeric = numeric;
            this.values = values;
        }
        Dimension.prototype.sameDimensionAs = function (other) {
            return this.setId === other.setId && this.index === other.index;
        };
        return Dimension;
    }());
    var CsvData = (function () {
        function CsvData(modelId, scenarioId, components, sets, datas, setDatas) {
            var _this = this;
            this.allColumnsReadOnly = false;
            this.clearSpreadsheet = function () {
                _this.datas = _this.serialize();
                _this.spreadsheetVisible = false;
                _this.unshownData = [];
                _this.spreadsheetSettings = null;
                _this.spreadsheetItems = [];
            };
            this.changeColumnSet = function () {
                _this.dimensionStore.setAxisSet(_this.columnSetId);
                _this.showSpreadsheet();
                _this.filterData();
            };
            this.showSpreadsheet = function () {
                var componentDimensions = _.map(_.orderBy(_this.components, function (c) { return c.name; }), function (component) {
                    var dimensions = _this.dimensionStore.getDimensionsForComponent(component);
                    var columnDimensions = _.filter(dimensions, function (d) { return d !== _this.dimensionStore.getAxisDimension(); });
                    return {
                        component: component,
                        columnDimensions: columnDimensions,
                        rows: _.reduce(columnDimensions, function (res, d) { return res * d.values.length; }, 1),
                        data: _this.getDataForComponent(component.id),
                        usesValueColumn: dimensions.length === columnDimensions.length,
                    };
                });
                var rowCount = _.sumBy(componentDimensions, function (pd) { return pd.rows; });
                _this.setupSpreadsheet(rowCount);
                _.forEach(componentDimensions, function (componentDimension, componentDimensionIndex) {
                    var startingRow = _.sum(_.map(componentDimensions.slice(0, componentDimensionIndex), function (ppd) { return ppd.rows; }));
                    for (var rowIndex = startingRow; rowIndex < startingRow + componentDimension.rows; rowIndex++) {
                        _this.spreadsheetItems[rowIndex][0] = componentDimension.component.name;
                        _this.spreadsheetItems[rowIndex][_this.spreadsheetSettings.columns.length] = componentDimension.component.id;
                        _this.spreadsheetItems[rowIndex][_this.spreadsheetSettings.columns.length + 1] = componentDimension.usesValueColumn ? 1 : 0;
                    }
                    ;
                    var currentRowGroups = 1;
                    _.forEach(_this.dimensionStore.getColumnDimensions(), function (setData, columnIndex) {
                        if (_.some(componentDimension.columnDimensions, function (d) { return d === setData; })) {
                            var repetitionSize = componentDimension.rows / currentRowGroups;
                            var lumpSize = repetitionSize / setData.values.length;
                            var repetitions = componentDimension.rows / repetitionSize;
                            for (var rep = 0; rep < repetitions; rep++) {
                                _.forEach(setData.values, function (val, valueIndex) {
                                    for (var i = 0; i < lumpSize; i++) {
                                        var rowIndex = startingRow + rep * repetitionSize + valueIndex * lumpSize + i;
                                        _this.spreadsheetItems[rowIndex][columnIndex + 1] = val.value;
                                    }
                                    ;
                                });
                            }
                            ;
                            currentRowGroups = currentRowGroups * setData.values.length;
                        }
                        else {
                            for (var rowIndex = startingRow; rowIndex < startingRow + componentDimension.rows; rowIndex++) {
                                _this.spreadsheetItems[rowIndex][columnIndex + 1] = '-';
                            }
                            ;
                        }
                    });
                });
                _this.loadData(componentDimensions);
                _this.spreadsheetVisible = true;
            };
            this.setupSpreadsheet = function (rowCount) {
                var axisDimension = _this.dimensionStore.getAxisDimension();
                var columnProperties = [{
                        readOnly: true,
                    }];
                _.forEach(_this.dimensionStore.getColumnDimensions(), function () {
                    columnProperties.push({
                        readOnly: true
                    });
                });
                if (axisDimension) {
                    _.forEach(axisDimension.values, function () {
                        columnProperties.push({
                            readOnly: _this.allColumnsReadOnly,
                            type: 'numeric',
                            format: '0.[000000000]',
                        });
                    });
                }
                ;
                if (_this.dimensionStore.needsValueColumn()) {
                    columnProperties.push({
                        readOnly: _this.allColumnsReadOnly,
                        type: 'numeric',
                        format: '0.[000000000]',
                    });
                }
                ;
                var columnHeaders = [_this.typeColumnName].concat(_.map(_this.dimensionStore.getColumnDimensions(), function (s) { return s.name; }));
                if (axisDimension) {
                    _.forEach(axisDimension.values, function (v) {
                        var headerHtml = "<span title=\"" + v.displayName + "\">" + v.value + "</span>";
                        columnHeaders.push(headerHtml);
                    });
                }
                ;
                if (_this.dimensionStore.needsValueColumn()) {
                    columnHeaders.push('Value');
                }
                columnHeaders.push('id');
                columnHeaders.push('usesValueColumn');
                var visibleColumnCount = columnHeaders.length - 2;
                var needsValueColumn = _this.dimensionStore.needsValueColumn();
                var settings = {
                    columnSorting: true,
                    colHeaders: columnHeaders,
                    columns: columnProperties,
                    manualColumnMove: true,
                    manualColumnFreeze: true,
                    contextMenu: ['freeze_column'],
                };
                if (!_this.allColumnsReadOnly) {
                    settings.cells = function (row, col) {
                        var usesValueColumn = _this.spreadsheetItems[row] && _this.spreadsheetItems[row][columnHeaders.length - 1];
                        if (usesValueColumn && col < visibleColumnCount - 1) {
                            return {
                                readOnly: true,
                            };
                        }
                        if (!usesValueColumn && needsValueColumn && col === visibleColumnCount - 1) {
                            return {
                                readOnly: true,
                            };
                        }
                        return {};
                    };
                }
                _this.spreadsheetSettings = settings;
                _this.spreadsheetItems = _.times(rowCount, function () {
                    return _.map(columnHeaders, function () { return null; });
                });
            };
            this.loadData = function (componentDimensions) {
                var valueColumnStartIndex = _this.dimensionStore.getColumnDimensions().length + 1;
                var axisDimension = _this.dimensionStore.getAxisDimension();
                var dataMappingFunction = function (componentDimension, rowContents, colValue) {
                    var actualOrderedValues = _.map(componentDimension.data.sets, function (set) {
                        var dimension = _.find(componentDimension.columnDimensions, function (dim) { return dim.setId === set.id && dim.index === set.index; });
                        if (dimension == null) {
                            if (axisDimension && axisDimension.setId === set.id && axisDimension.index === set.index)
                                return colValue;
                            throw ('this.actualSetValue');
                        }
                        var column = _.findIndex(_this.dimensionStore.getColumnDimensions(), dimension) + 1;
                        return rowContents[column];
                    });
                    return actualOrderedValues.join('|');
                };
                _.forEach(componentDimensions, function (componentDimension, componentDimensionIndex) {
                    var startingRow = _.sum(_.map(componentDimensions.slice(0, componentDimensionIndex), function (ppd) { return ppd.rows; }));
                    if (!componentDimension.data) {
                        var defaultComponentData = _this.getDefaultDataForComponent(componentDimension.component);
                        for (var row_1 = startingRow; row_1 < startingRow + componentDimension.rows; row_1++) {
                            if (componentDimension.usesValueColumn) {
                                for (var i = 0; i < axisDimension.values.length; i++) {
                                    _this.spreadsheetItems[row_1][valueColumnStartIndex + i] = '-';
                                }
                                _this.spreadsheetItems[row_1][valueColumnStartIndex + axisDimension.values.length] = defaultComponentData.defaultValue;
                            }
                            else {
                                for (var i = 0; i < axisDimension.values.length; i++) {
                                    _this.spreadsheetItems[row_1][valueColumnStartIndex + i] = defaultComponentData.defaultValue;
                                }
                                if (_this.dimensionStore.needsValueColumn()) {
                                    _this.spreadsheetItems[row_1][valueColumnStartIndex + axisDimension.values.length] = '-';
                                }
                            }
                        }
                        _this.unshownData.push(defaultComponentData);
                        return;
                    }
                    var stringgedDataMap = {};
                    _.forEach(componentDimension.data.data, function (data) {
                        stringgedDataMap[data.c.join('|')] = data;
                    });
                    if (componentDimension.usesValueColumn) {
                        for (var row_2 = startingRow; row_2 < startingRow + componentDimension.rows; row_2++) {
                            for (var i = 0; i < axisDimension.values.length; i++) {
                                _this.spreadsheetItems[row_2][valueColumnStartIndex + i] = '-';
                            }
                            var mappedCoordinates = dataMappingFunction(componentDimension, _this.spreadsheetItems[row_2]);
                            var found = stringgedDataMap[mappedCoordinates];
                            if (found) {
                                delete stringgedDataMap[mappedCoordinates];
                            }
                            var value = found ? found.v : _this.getDefaultValueForData(componentDimension.data);
                            _this.spreadsheetItems[row_2][valueColumnStartIndex + axisDimension.values.length] = value;
                        }
                    }
                    else {
                        for (var row = startingRow; row < startingRow + componentDimension.rows; row++) {
                            for (var i = 0; i < axisDimension.values.length; i++) {
                                var mappedCoordinates = dataMappingFunction(componentDimension, _this.spreadsheetItems[row], axisDimension.values[i].value);
                                var found = stringgedDataMap[mappedCoordinates];
                                if (found) {
                                    delete stringgedDataMap[mappedCoordinates];
                                }
                                var value = found ? found.v : _this.getDefaultValueForData(componentDimension.data);
                                _this.spreadsheetItems[row][valueColumnStartIndex + i] = value;
                            }
                            if (_this.dimensionStore.needsValueColumn()) {
                                _this.spreadsheetItems[row][valueColumnStartIndex + axisDimension.values.length] = '-';
                            }
                        }
                    }
                    var remainingData = [];
                    _.forOwn(stringgedDataMap, function (val) { return remainingData.push(val); });
                    _this.unshownData.push(_this.getRemainingDataForComponent(componentDimension.data, remainingData));
                });
            };
            this.filterData = function () {
                var sourceData = _this.spreadsheetItems.concat(_this.hiddenFilteredRows);
                _this.spreadsheetItems = [];
                _this.hiddenFilteredRows = [];
                var parameterIdColumnIndex = _this.spreadsheetSettings.columns.length;
                var columnDimensionIds = _.map(_this.dimensionStore.getColumnDimensions(), function (d) { return d.setId; });
                var activeSetFilters = _.filter(_this.currentSetFilters, function (sf) { return _.some(columnDimensionIds, function (cdi) { return cdi === sf.id; }); });
                var indexFilters = _.map(activeSetFilters, function (sf) {
                    return {
                        index: _.indexOf(columnDimensionIds, sf.id) + 1,
                        regex: sf.query,
                    };
                });
                _.forEach(sourceData, function (row) {
                    if (_.some(_this.currentComponentFilters, function (c) { return c.id === row[parameterIdColumnIndex]; })) {
                        if (activeSetFilters.length) {
                            var passesAllSetFilters = _.every(indexFilters, function (f) { return row[f.index].search(f.regex) !== -1; });
                            if (passesAllSetFilters) {
                                _this.spreadsheetItems.push(row);
                            }
                            else {
                                _this.hiddenFilteredRows.push(row);
                            }
                        }
                        else {
                            _this.spreadsheetItems.push(row);
                        }
                    }
                    else {
                        _this.hiddenFilteredRows.push(row);
                    }
                });
            };
            this.updateFilters = function (filteredComponents, setFilters) {
                _this.currentComponentFilters = filteredComponents;
                _this.currentSetFilters = setFilters;
                _this.filterData();
            };
            this.serialize = function () {
                var allData = _this.spreadsheetItems.concat(_this.hiddenFilteredRows);
                return _.map(_.groupBy(allData, function (r) { return r[_this.spreadsheetSettings.columns.length]; }), function (rows, componentId) {
                    var unshownData = _this.getUnshownDataForComponent(componentId);
                    var data = unshownData.data.slice();
                    var axisDimension = _this.dimensionStore.getAxisDimension();
                    var columns = _this.dimensionStore.getColumnDimensions();
                    var columnIndexMap = _.map(unshownData.sets, function (dimension) {
                        var index = _.findIndex(columns, function (col) { return col.setId === dimension.id && col.index === dimension.index; });
                        if (index < 0)
                            return null;
                        return index + 1;
                    });
                    var coordinateFunction = function (row, valueIndex) {
                        return _.map(unshownData.sets, function (dimension, index) {
                            var mappedColumnIndex = columnIndexMap[index];
                            if (mappedColumnIndex)
                                return row[mappedColumnIndex].toString();
                            if (axisDimension.setId === dimension.id && axisDimension.index === dimension.index) {
                                return axisDimension.values[valueIndex].value;
                            }
                            throw 'err';
                        });
                    };
                    var axisColumnsStartIndex = _this.dimensionStore.getColumnDimensions().length + 1;
                    var valueColumnIndex = axisColumnsStartIndex + axisDimension.values.length;
                    _.forEach(rows, function (row) {
                        var rowUsesValueColumn = !!row[_this.spreadsheetSettings.columns.length + 1];
                        if (rowUsesValueColumn) {
                            var val = +row[valueColumnIndex];
                            if (_this.valueSameAsDefault(val, unshownData))
                                return;
                            var coordinates = coordinateFunction(row);
                            data.push({
                                c: coordinates,
                                v: val,
                            });
                        }
                        else {
                            for (var i = 0; i < axisDimension.values.length; i++) {
                                var val = +row[axisColumnsStartIndex + i];
                                if (_this.valueSameAsDefault(val, unshownData))
                                    continue;
                                var coordinates = coordinateFunction(row, i);
                                data.push({
                                    c: coordinates,
                                    v: val,
                                });
                            }
                        }
                    });
                    return _this.constructFullDataForComponent(unshownData, data);
                });
            };
            this.asTextFile = function () {
                var res = [];
                res.push(_this.spreadsheetSettings.colHeaders.slice(0, _this.spreadsheetSettings.columns.length).join(',') + "\r\n");
                _.forEach(_this.spreadsheetItems, function (row) {
                    var values = _.map(row.slice(0, _this.spreadsheetSettings.columns.length), function (val) {
                        return val === '-' ? '' : val;
                    });
                    res.push(values.join(',') + "\r\n");
                });
                return res;
            };
            this.scenarioId = scenarioId;
            this.modelId = modelId;
            this.sets = sets;
            this.components = components;
            this.datas = datas;
            this.dimensionStore = new CsvDimensionStore(modelId, sets, setDatas, components);
            var axisDimension = this.dimensionStore.getAxisDimension();
            this.columnSetId = axisDimension ? _.find(this.sets, function (s) { return s.id === axisDimension.setId; }).id : null;
            this.unshownData = [];
            this.currentComponentFilters = components;
            this.currentSetFilters = [];
            this.hiddenFilteredRows = [];
        }
        return CsvData;
    }());
    var ParameterDataCsv = (function (_super) {
        __extends(ParameterDataCsv, _super);
        function ParameterDataCsv(modelId, scenarioId, parameters, sets, parameterDatas, setDatas) {
            var _this = _super.call(this, modelId, scenarioId, parameters, sets, parameterDatas, setDatas) || this;
            _this.getDataForComponent = function (componentId) {
                return _.find(_this.datas, function (pd) { return pd.parameterId === componentId; });
            };
            _this.getUnshownDataForComponent = function (componentId) {
                return _.find(_this.unshownData, function (pd) { return pd.parameterId === componentId; });
            };
            _this.getDefaultDataForComponent = function (component) {
                return {
                    modelId: _this.modelId,
                    scenarioId: _this.scenarioId,
                    parameterId: component.id,
                    defaultValue: component.defaultValue,
                    sets: _.map(component.sets, function (setId, index) {
                        var instanceIndex = _(component.sets).slice(0, index).filter(function (sId) { return sId === setId; }).value().length;
                        return {
                            id: setId,
                            index: instanceIndex,
                        };
                    }),
                    data: [],
                };
            };
            _this.getRemainingDataForComponent = function (data, remainingItems) {
                return {
                    modelId: data.modelId,
                    scenarioId: data.scenarioId,
                    parameterId: data.parameterId,
                    defaultValue: data.defaultValue,
                    sets: data.sets,
                    data: remainingItems,
                };
            };
            _this.getDefaultValueForData = function (data) {
                return data.defaultValue;
            };
            _this.constructFullDataForComponent = function (data, dataArray) {
                return {
                    modelId: _this.modelId,
                    scenarioId: _this.scenarioId,
                    parameterId: data.parameterId,
                    defaultValue: data.defaultValue,
                    sets: data.sets,
                    data: dataArray,
                };
            };
            _this.valueSameAsDefault = function (value, data) {
                return value === data.defaultValue;
            };
            _this.typeColumnName = 'Parameter';
            _this.showSpreadsheet();
            return _this;
        }
        return ParameterDataCsv;
    }(CsvData));
    exports.ParameterDataCsv = ParameterDataCsv;
    var VariableResultCsv = (function (_super) {
        __extends(VariableResultCsv, _super);
        function VariableResultCsv(modelId, scenarioId, variables, sets, variableResults, setDatas) {
            var _this = _super.call(this, modelId, scenarioId, variables, sets, variableResults, setDatas) || this;
            _this.getDataForComponent = function (componentId) {
                return _.find(_this.datas, function (pd) { return pd.variableId === componentId; });
            };
            _this.getUnshownDataForComponent = function (componentId) {
                return _.find(_this.unshownData, function (pd) { return pd.variableId === componentId; });
            };
            _this.getDefaultDataForComponent = function (component) {
                return {
                    modelId: _this.modelId,
                    scenarioId: _this.scenarioId,
                    variableId: component.id,
                    defaultValue: null,
                    sets: _.map(component.sets, function (setId, index) {
                        var instanceIndex = _(component.sets).slice(0, index).filter(function (sId) { return sId === setId; }).value().length;
                        return {
                            id: setId,
                            index: instanceIndex,
                        };
                    }),
                    data: [],
                };
            };
            _this.getRemainingDataForComponent = function (data, remainingItems) {
                return {
                    modelId: data.modelId,
                    scenarioId: data.scenarioId,
                    variableId: data.variableId,
                    defaultValue: data.defaultValue,
                    sets: data.sets,
                    data: remainingItems,
                };
            };
            _this.getDefaultValueForData = function (data) {
                return data.defaultValue;
            };
            _this.constructFullDataForComponent = function (data, dataArray) {
                return {
                    modelId: _this.modelId,
                    scenarioId: _this.scenarioId,
                    variableId: data.variableId,
                    defaultValue: data.defaultValue,
                    sets: data.sets,
                    data: dataArray,
                };
            };
            _this.valueSameAsDefault = function (value, data) {
                return value === data.defaultValue;
            };
            _this.typeColumnName = 'Variable';
            _this.allColumnsReadOnly = true;
            _this.showSpreadsheet();
            return _this;
        }
        return VariableResultCsv;
    }(CsvData));
    exports.VariableResultCsv = VariableResultCsv;
    var CsvDimensionStore = (function () {
        function CsvDimensionStore(modelId, sets, setDatas, components) {
            var _this = this;
            this.assignInitialAxisSet = function () {
                if (_this.dimensions.length === 0)
                    return;
                var numericSets = _.filter(_this.setDatas, function (s) { return s.numeric; });
                var initialSet = numericSets.length ? _.maxBy(numericSets, function (s) { return s.getValueCount(); }) : _.maxBy(_this.setDatas, function (s) { return s.getValueCount(); });
                _this.setAxisSet(initialSet.setId);
            };
            this.setAxisSet = function (setId) {
                _this.axisDimension = _.find(_this.dimensions, function (d) { return d.setId === setId && d.index === 0; });
            };
            this.getDimensionsForComponent = function (component) {
                return _.map(component.sets, function (setId, i) {
                    var previousSetIds = component.sets.slice(0, i);
                    var index = _.filter(previousSetIds, function (psId) { return psId === setId; }).length;
                    return _.find(_this.dimensions, function (d) { return d.setId === setId && d.index === index; });
                });
            };
            this.getAxisDimension = function () {
                return _this.axisDimension;
            };
            this.getColumnDimensions = function () {
                return _.filter(_this.dimensions, function (d) { return d !== _this.getAxisDimension(); });
            };
            this.getAllDimensions = function () {
                return _this.dimensions;
            };
            this.needsValueColumn = function () {
                if (_this.axisDimension == null)
                    return true;
                return !_.every(_this.components, function (c) { return _.some(c.sets, function (sId) { return sId === _this.axisDimension.setId; }); });
            };
            this.dimensions = [];
            this.components = components;
            this.setDatas = _.map(sets, function (set) {
                var setData = _.find(setDatas, function (sd) { return sd.setId === set.id; });
                return new setDataModel.SetData(modelId, set, setData);
            });
            _.forEach(components, function (component) {
                _.forEach(component.sets, function (setId, i) {
                    var previousSetIds = component.sets.slice(0, i);
                    var index = _.filter(previousSetIds, function (psId) { return psId === setId; }).length;
                    var dimension = _.find(_this.dimensions, function (d) { return d.setId === setId && d.index === index; });
                    if (dimension) {
                        return;
                    }
                    var setData = _.find(_this.setDatas, function (sd) { return sd.setId === setId; });
                    dimension = {
                        setId: setId,
                        index: index,
                        name: setData.setName,
                        numeric: setData.numeric,
                        values: _.map(setData.getValueNamePairs(), function (valueName) {
                            var onlyDisplayValue = valueName.value === valueName.name || !valueName.name;
                            return {
                                value: valueName.value,
                                displayName: onlyDisplayValue ? valueName.value : valueName.value + " (" + valueName.name + ")",
                            };
                        }),
                    };
                    _this.dimensions.push(dimension);
                });
            });
            this.assignInitialAxisSet();
        }
        return CsvDimensionStore;
    }());
});
//# sourceMappingURL=csvData.js.map