define(["require", "exports", "lodash", "node-uuid", "urls", "models/set", "models/parameter", "models/variable", "models/objectiveFunction", "models/constraint", "models/modelDependency"], function (require, exports, _, uuid, urls, setModel, parameterModel, variableModel, objectiveFunctionModel, constraintModel, modelDependency) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var ModelConstraintGroup = (function () {
        function ModelConstraintGroup(id, name, constraints, selectedConstraints, data, changeHandler) {
            var _this = this;
            this.id = id;
            this.name = name;
            var sortedConstraints = _.sortBy(constraints, function (c) { return c.name; });
            this.constraints = _.map(sortedConstraints, function (c) {
                return {
                    data: new constraintModel.Constraint(data, null, [], c),
                    selected: _.some(selectedConstraints, function (constraintId) { return constraintId == c.id; }),
                };
            });
            this.selected = _.every(this.constraints, function (c) { return c.selected; });
            this.toggleGroupConstraints = function (checked) {
                var checkbox = checked.target;
                _.forEach(_this.constraints, function (c) { c.selected = checkbox.checked; });
                changeHandler();
            };
            this.selectedConstraints = function () {
                return _(_this.constraints).filter(function (c) { return c.selected; }).map(function (c) { return c.data; }).value();
            };
        }
        return ModelConstraintGroup;
    }());
    exports.ModelConstraintGroup = ModelConstraintGroup;
    var Model = (function () {
        function Model(sets, parameters, variables, objectiveFunctions, constraintGroups, constraints, model) {
            var _this = this;
            this.toggleObjectiveFunction = function (event, objFun) {
                var checkbox = event.target;
                _.forEach(_this.objectiveFunctions, function (other) { other.selected = false; });
                objFun.selected = checkbox.checked;
                _this.recalculateDependencies();
            };
            this.toggleConstraint = function (event, constraint) {
                var checkbox = event.target;
                constraint.selected = checkbox.checked;
                _this.recalculateDependencies();
            };
            this.toggleAllConstraints = function (event) {
                var checkbox = event.target;
                _.forEach(_this.constraintGroups, function (cg) {
                    _.forEach(cg.constraints, function (c) {
                        c.selected = checkbox.checked;
                    });
                    cg.selected = checkbox.checked;
                });
                _this.recalculateDependencies();
            };
            this.recalculateDependencies = function () {
                var dependencies = new modelDependency.ModelDependency([], [], []);
                var selectedObjectiveFunctions = _.filter(_this.objectiveFunctions, function (objFun) { return objFun.selected; });
                _.forEach(selectedObjectiveFunctions, function (objFun) {
                    dependencies = dependencies.join(objFun.data.getDependencies());
                });
                _.forEach(_this.selectedConstraints(), function (constraint) {
                    dependencies = dependencies.join(constraint.getDependencies());
                });
                _this.markDependencies(dependencies);
            };
            this.markDependencies = function (dependencies) {
                _.forEach(_this.sets, function (s) {
                    s.selected = _.some(dependencies.sets, function (depSet) {
                        return s.data.id == depSet;
                    });
                });
                _.forEach(_this.parameters, function (p) {
                    p.selected = _.some(dependencies.parameters, function (depPar) {
                        return p.data.id == depPar;
                    });
                });
                _.forEach(_this.variables, function (v) {
                    v.selected = _.some(dependencies.variables, function (depVar) {
                        return v.data.id == depVar;
                    });
                });
            };
            this.selectedSets = function () {
                return _(_this.sets).filter(function (s) { return s.selected; }).map(function (s) { return s.data; }).value();
            };
            this.selectedParameters = function () {
                return _(_this.parameters).filter(function (p) { return p.selected; }).map(function (p) { return p.data; }).value();
            };
            this.selectedVariables = function () {
                return _(_this.variables).filter(function (v) { return v.selected; }).map(function (v) { return v.data; }).value();
            };
            this.selectedObjectiveFunction = function () {
                return _(_this.objectiveFunctions).filter(function (o) { return o.selected; }).map(function (o) { return o.data; }).first();
            };
            this.selectedConstraints = function () {
                return _.flatten(_.map(_this.constraintGroups, function (cg) { return cg.selectedConstraints(); }));
            };
            this.selectedConstraintGroups = function () {
                return _.filter(_this.constraintGroups, function (cg) { return _.some(cg.constraints, function (c) { return c.selected; }); });
            };
            this.serialize = function () {
                return {
                    id: _this.id,
                    name: _this.name,
                    description: _this.description,
                    sets: _.map(_this.selectedSets(), function (s) { return s.id; }),
                    parameters: _.map(_this.selectedParameters(), function (p) { return p.id; }),
                    variables: _.map(_this.selectedVariables(), function (v) { return v.id; }),
                    objectiveFunction: _this.selectedObjectiveFunction().id,
                    constraints: _.map(_this.selectedConstraints(), function (c) { return c.id; }),
                };
            };
            this.asTextFile = function () {
                var res = [];
                res.push('###############');
                res.push('#    Sets     #');
                res.push('###############');
                res.push('#');
                _.forEach(_this.selectedSets(), function (s) {
                    res.push(s.asModelString());
                });
                res.push('#');
                res.push('#####################');
                res.push('#    Parameters     #');
                res.push('#####################');
                res.push('#');
                _.forEach(_this.selectedParameters(), function (p) {
                    res.push(p.asModelString());
                });
                res.push('#');
                res.push('##########################');
                res.push('#    Model Variables     #');
                res.push('##########################');
                res.push('#');
                _.forEach(_this.selectedVariables(), function (v) {
                    res.push(v.asModelString());
                });
                res.push('#');
                res.push('######################');
                res.push('# Objective Function #');
                res.push('######################');
                res.push('#');
                res.push(_this.selectedObjectiveFunction().asModelString());
                res.push('#');
                res.push('#####################');
                res.push('#    Constraints    #');
                res.push('#####################');
                res.push('#');
                _.forEach(_this.selectedConstraintGroups(), function (cg) {
                    res.push("#  " + cg.name);
                    _.forEach(cg.selectedConstraints(), function (c) {
                        res.push(c.asModelString());
                    });
                    res.push('#');
                });
                res.push('#####################');
                res.push('#');
                res.push('solve;');
                res.push('#');
                res.push('#####################');
                res.push('#');
                res.push('################');
                res.push('#    Output    #');
                res.push('################');
                res.push('#');
                _.forEach(_this.selectedVariables(), function (v) {
                    res.push(v.asOutputString());
                });
                res.push('#');
                res.push('end;');
                res.push('');
                return res;
            };
            this.asScenarioMetaDataTextFile = function (scenarioId) {
                var res = [];
                res.push(urls.baseUrl);
                res.push(scenarioId);
                res.push(_this.id);
                _.forEach(_this.selectedVariables(), function (v) {
                    res.push(v.asMetaData());
                });
                return res;
            };
            if (model) {
                this.id = model.id;
                this.name = model.name;
                this.description = model.description;
            }
            else {
                this.id = uuid.v4();
                this.name = '';
                this.description = '';
            }
            var data = {
                sets: sets,
                parameters: parameters,
                variables: variables,
            };
            this.sets = _.map(_.sortBy(sets, function (s) { return s.name; }), function (s) {
                return {
                    data: new setModel.Set(s),
                    selected: model ? _.some(model.sets, function (setId) { return setId == s.id; }) : false,
                };
            });
            this.parameters = _.map(_.sortBy(parameters, function (p) { return p.name; }), function (p) {
                return {
                    data: new parameterModel.Parameter(sets, p),
                    selected: model ? _.some(model.parameters, function (parameterId) { return parameterId == p.id; }) : false,
                };
            });
            this.variables = _.map(_.sortBy(variables, function (v) { return v.name; }), function (v) {
                return {
                    data: new variableModel.Variable(sets, v),
                    selected: model ? _.some(model.variables, function (variableId) { return variableId == v.id; }) : false,
                };
            });
            this.objectiveFunctions = _.map(_.sortBy(objectiveFunctions, function (o) { return o.name; }), function (o) {
                return {
                    data: new objectiveFunctionModel.ObjectiveFunction(data, null, o),
                    selected: model ? model.objectiveFunction == o.id : false,
                };
            });
            var modelConstraints = model ? model.constraints : [];
            var sortedConstraintGroups = _.sortBy(constraintGroups, function (cg) { return cg.name; });
            var constraintGroupList = _.map(sortedConstraintGroups, function (cg) {
                var groupConstraints = _.filter(constraints, function (c) { return c.constraintGroupId == cg.id; });
                return new ModelConstraintGroup(cg.id, cg.name, groupConstraints, modelConstraints, data, _this.recalculateDependencies);
            });
            var ungroupedConstraints = _.filter(constraints, function (c) { return c.constraintGroupId == null; });
            constraintGroupList.push(new ModelConstraintGroup(null, 'Ungrouped', ungroupedConstraints, modelConstraints, data, this.recalculateDependencies));
            this.constraintGroups = constraintGroupList;
            this.allConstraintsSelected = this.selectedConstraints().length == constraints.length;
        }
        return Model;
    }());
    exports.Model = Model;
});
//# sourceMappingURL=model.js.map