define(["require", "exports", "lodash"], function (require, exports, _) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var ModelDependency = (function () {
        function ModelDependency(sets, parameters, variables) {
            var _this = this;
            this.join = function (other) {
                var sets = _.uniq(_this.sets.concat(other.sets));
                var parameters = _.uniq(_this.parameters.concat(other.parameters));
                var variables = _.uniq(_this.variables.concat(other.variables));
                return new ModelDependency(sets, parameters, variables);
            };
            this.sets = sets;
            this.parameters = parameters;
            this.variables = variables;
        }
        return ModelDependency;
    }());
    exports.ModelDependency = ModelDependency;
});
//# sourceMappingURL=modelDependency.js.map