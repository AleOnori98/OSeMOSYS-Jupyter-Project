define(["require", "exports", "lodash"], function (require, exports, _) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var VariableResult = (function () {
        function VariableResult(variable, variableResult, sets, setData, withChart, settings) {
            var _this = this;
            this.xSetIndex = function () {
                return _.findIndex(_this.sets, function (s) { return s.id == _this.xSet.id; });
            };
            this.groupSetIndex = function () {
                return _this.groupSet != null ? _.findIndex(_this.sets, function (s) { return s.id == _this.groupSet.id; }) : null;
            };
            this.updateGroupOptions = function () {
                _this.groupOptions = _.filter(_this.sets, function (s) { return s.id != _this.xSet.id; });
                if (_this.groupSet == null || !_.some(_this.groupOptions, { id: _this.groupSet.id })) {
                    _this.groupSet = _.first(_this.groupOptions);
                }
                _this.selectGrouping();
            };
            this.addGroupDataHandler = function (handler) {
                _this.groupDataHandler = handler;
                if (_this.groupSet) {
                    var groupSetData = _.find(_this.setData, function (sd) { return sd.setId == _this.groupSet.id; });
                    _this.groupDataHandler(groupSetData);
                }
            };
            this.changeSetDataFilters = function (setDataValues) {
                _this.setDataFilters = setDataValues;
                _this.updateChart();
            };
            this.changeChartHeight = function (height) {
                _this.chartHeight = height;
                _this.chartOptions.chart.height = height;
            };
            this.selectGrouping = function () {
                if (_this.groupDataHandler) {
                    var groupSetData = _.find(_this.setData, function (sd) { return sd.setId == _this.groupSet.id; });
                    _this.groupDataHandler(groupSetData);
                }
                _this.updateChart();
            };
            this.getUnfilteredChartData = function () {
                var axisSetData = _.find(_this.setData, function (sd) { return sd.setId == _this.xSet.id; });
                var axisValues = _.map(axisSetData.items, function (i) { return i.value; });
                var xSetIndex = _this.xSetIndex();
                var groupSetId = _this.groupSet ? _this.groupSet.id : null;
                var groupSetData = _.find(_this.setData, function (sd) { return sd.setId == groupSetId; });
                if (!groupSetData) {
                    var values = _.map(axisValues, function (k) {
                        var axisPointValues = _.filter(_this.data, function (d) { return d.c[xSetIndex] == k; });
                        return {
                            x: _this.resolveSetDataText(_this.xSet, k),
                            y: _.reduce(axisPointValues, function (total, val) { return total + val.v; }, 0),
                        };
                    });
                    return [{
                            key: _this.name,
                            values: values,
                            color: '#1F77B4',
                        }];
                }
                var groups = _.map(groupSetData.items, function (i) { return i.value; });
                return _.map(groups, function (group) {
                    var groupData = _.filter(_this.data, function (d) { return d.c[_this.groupSetIndex()] == group; });
                    var values = _.map(axisValues, function (k) {
                        var axisPointValues = _.filter(groupData, function (d) { return d.c[xSetIndex] == k; });
                        return {
                            x: _this.resolveSetDataText(_this.xSet, k),
                            y: _.reduce(axisPointValues, function (total, val) { return total + val.v; }, 0),
                        };
                    });
                    return {
                        key: _this.resolveSetDataText(_this.groupSet, group),
                        values: values,
                        color: _this.resolveSetDataColor(_this.groupSet, group),
                    };
                });
            };
            this.updateChart = function () {
                _this.pending.chartOptions = {
                    chart: _.assign({}, defaultChartOptions),
                };
                _this.pending.chartOptions.chart.type = _this.xSet.numeric ? 'stackedAreaChart' : 'multiBarChart';
                _this.pending.chartOptions.chart.yAxis.axisLabel = _this.variable.unit;
                _this.pending.chartOptions.chart.height = _this.chartHeight;
                var unfilteredChartData = _this.getUnfilteredChartData();
                _this.pending.chartData = _.filter(unfilteredChartData, function (d) {
                    if (!_this.setDataFilters)
                        return true;
                    var namedSetDataFilters = _.map(_this.setDataFilters, function (s) { return _this.resolveSetDataText(_this.groupSet, s); });
                    return _.includes(namedSetDataFilters, d.key);
                });
            };
            this.getMinY = function () {
                var allValues = _.map(_this.pending.chartData, function (cd) {
                    return cd.values;
                });
                var flatValues = _.flatten(allValues);
                if (_this.xSet.numeric) {
                    var groupedValues = _.groupBy(flatValues, function (fv) {
                        return fv.x;
                    });
                    var groupSums = _.map(groupedValues, function (gv) {
                        return _.sumBy(gv, function (val) {
                            return val.y;
                        });
                    });
                    var minSum = _.min(groupSums);
                    return minSum < 0 ? roundUp(minSum) : 0;
                }
                else {
                    var min = _.minBy(flatValues, function (fv) { return fv.y; });
                    return min.y < 0 ? roundUp(min.y) : 0;
                }
            };
            this.getMaxY = function () {
                var allValues = _.map(_this.pending.chartData, function (cd) {
                    return cd.values;
                });
                var flatValues = _.flatten(allValues);
                if (_this.xSet.numeric) {
                    var groupedValues = _.groupBy(flatValues, function (fv) {
                        return fv.x;
                    });
                    var groupSums = _.map(groupedValues, function (gv) {
                        return _.sumBy(gv, function (val) {
                            return val.y;
                        });
                    });
                    var maxSum = _.max(groupSums);
                    return maxSum > 0 ? roundUp(maxSum) : 0;
                }
                else {
                    var max = _.maxBy(flatValues, function (fv) { return fv.y; });
                    return max.y > 0 ? roundUp(max.y) : 0;
                }
            };
            this.setYRange = function (from, to) {
                _this.pending.chartOptions.chart.yDomain = [from, to];
            };
            this.clear = function () {
                _this.chartOptions = null;
                _this.chartData = null;
            };
            this.draw = function () {
                _this.chartOptions = _this.pending.chartOptions;
                _this.chartData = _this.pending.chartData;
            };
            this.resolveSetDataText = function (set, value) {
                if (set == null)
                    return _this.name;
                if (_this.useSetValues) {
                    return value;
                }
                var actualSetDataEntry = _this.resolveSetDataEntry(set, value);
                if (actualSetDataEntry == null)
                    return value;
                return set.numeric ? +actualSetDataEntry.value : actualSetDataEntry.name;
            };
            this.resolveSetDataColor = function (set, value) {
                var defaultColor = '#1F77B4';
                if (set == null)
                    return defaultColor;
                var actualSetDataEntry = _this.resolveSetDataEntry(set, value);
                if (actualSetDataEntry == null)
                    return defaultColor;
                return actualSetDataEntry.color;
            };
            this.resolveSetDataEntry = function (set, value) {
                if (set == null)
                    return null;
                var actualSetData = _.find(_this.setData, function (sd) { return sd.setId == set.id; });
                return _.find(actualSetData.items, function (i) { return i.value == value; });
            };
            this.toggleLegend = function (visible) {
                defaultChartOptions.showControls = visible;
                defaultChartOptions.showLegend = visible;
                _this.pending.chartOptions.chart.showControls = visible;
                _this.pending.chartOptions.chart.showLegend = visible;
                if (_this.chartOptions != null) {
                    _this.chartOptions.chart.showControls = visible;
                    _this.chartOptions.chart.showLegend = visible;
                }
            };
            this.toggleUseSetDataDescriptions = function (useDescriptions) {
                _this.useSetValues = !useDescriptions;
                _this.updateChart();
                var minY = _this.getMinY();
                var maxY = _this.getMaxY();
                _this.setYRange(minY, maxY);
                _this.draw();
            };
            this.variableId = variableResult.variableId;
            this.scenarioId = variableResult.scenarioId;
            this.modelId = variableResult.modelId;
            this.variable = variable;
            this.name = variable.name;
            this.description = variable.description;
            this.defaultValue = variableResult.defaultValue;
            this.data = variableResult.data;
            this.sets = _.map(variable.sets, function (s) { return _.find(sets, function (ss) { return ss.id == s.value; }); });
            this.setData = setData;
            if (withChart) {
                this.pending = {};
                this.xSet = _(this.sets).filter(function (s) { return s.numeric; }).first() || _.first(this.sets);
                this.updateGroupOptions();
                this.useSetValues = false;
                this.chartHeight = 450;
            }
            if (settings) {
                settings.addLegendSubscriber(this.toggleLegend);
                settings.addUseSetDataDescriptionSubscriber(this.toggleUseSetDataDescriptions);
                settings.addSetDataFilterSubscriber(this.changeSetDataFilters);
                settings.addChartHeightSubscriber(this.changeChartHeight);
                this.chartHeight = settings.chartHeight;
            }
        }
        return VariableResult;
    }());
    exports.VariableResult = VariableResult;
    var roundUp = function (input) {
        if (input == 0)
            return 0;
        var negative = input < 0;
        if (negative)
            input = -input;
        var digits = Math.ceil(Math.log(input) / Math.log(10));
        var roundingMultiplier = Math.pow(10, digits - 2);
        var normalizedInput = input / roundingMultiplier;
        var roundedNormalizedInput = Math.ceil(normalizedInput);
        var roundedValue;
        if (roundingMultiplier > 1) {
            roundedValue = roundedNormalizedInput * roundingMultiplier;
        }
        else {
            var roundingDivisor = 1 / roundingMultiplier;
            roundedValue = roundedNormalizedInput / roundingDivisor;
        }
        return negative ? -roundedValue : roundedValue;
    };
    var defaultChartOptions = {
        margin: {
            top: 20,
            right: 20,
            bottom: 30,
            left: 60
        },
        x: function (d) {
            return d.x;
        },
        y: function (d) {
            return d.y;
        },
        useVoronoi: false,
        clipEdge: true,
        transitionDuration: 500,
        useInteractiveGuideline: true,
        xAxis: {
            showMaxMin: false,
        },
        yAxis: {
            showMaxMin: true,
        },
        showControls: true,
        showLegend: true,
        yDomain: null,
    };
});
//# sourceMappingURL=variableResult.js.map