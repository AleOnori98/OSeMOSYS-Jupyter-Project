define(["require", "exports", "lodash", "models/setData", "models/parameterDataStringSerializer"], function (require, exports, _, setDataModel, parameterDataSerializer) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var Builder = (function () {
        function Builder($q, setDataService, parameterDataService, parameters, scenarioId, modelId, setModels) {
            var _this = this;
            this.addParameter = function (parameterId) {
                var loaded = _this.$q.defer();
                var req = _this.parameterDataService.get({ parameterId: parameterId, scenarioId: _this.scenarioId }).$promise;
                var load = _this.$q.all([req, _this.setsLoading]).then(function (res) {
                    var parameter = _.find(_this.parameters, function (p) { return p.id == parameterId; }).serialize();
                    var parameterData = res[0];
                    var dependentSetData = _.map(parameter.sets, function (s) {
                        return _.find(_this.setData, function (sd) { return sd.setId == s; });
                    });
                    _this.parameterData.push(new parameterDataSerializer.ParameterData(parameter, dependentSetData, parameterData));
                    loaded.resolve();
                });
                _this.parameterDataReqs.push(load);
                return loaded;
            };
            this.build = function () {
                return _this.$q.all(_this.parameterDataReqs).then(function () {
                    var res = [];
                    res.push('###############');
                    res.push('#    Sets     #');
                    res.push('###############');
                    res.push('#');
                    _.forEach(_this.setData, function (s) {
                        res.push("set " + s.setName + " := " + s.getGlpkReadyValues().join(' ') + " ;");
                    });
                    res.push('');
                    res.push('');
                    res.push('#####################');
                    res.push('#    Parameters     #');
                    res.push('#####################');
                    res.push('#');
                    _.forEach(_this.parameterData, function (p) {
                        res = res.concat(p.asDataString());
                        res.push('');
                    });
                    res.push('#');
                    res.push('end;');
                    res.push('');
                    return res.join('\r\n');
                    ;
                });
            };
            this.$q = $q;
            this.parameterDataService = parameterDataService;
            this.parameters = parameters;
            this.scenarioId = scenarioId;
            this.modelId = modelId;
            this.setData = [];
            this.parameterData = [];
            this.parameterDataReqs = [];
            var deferred = this.$q.defer();
            this.setsLoading = deferred.promise;
            var setDataReqs = _.map(setModels, function (sm) {
                return setDataService.get({ setId: sm.id, modelId: _this.modelId }).$promise.then(function (data) {
                    _this.setData.push(new setDataModel.SetData(_this.modelId, sm.serialize(), data));
                });
            });
            $q.all(setDataReqs).then(function () { deferred.resolve(true); }, function () { return deferred.reject(false); });
        }
        return Builder;
    }());
    exports.Builder = Builder;
});
//# sourceMappingURL=dataStringBuilder.js.map