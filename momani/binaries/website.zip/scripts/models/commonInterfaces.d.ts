﻿interface IRenderable {
    render: () => string
}