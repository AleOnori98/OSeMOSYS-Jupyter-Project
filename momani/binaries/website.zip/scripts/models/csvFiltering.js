define(["require", "exports", "lodash"], function (require, exports, _) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var Filter = (function () {
        function Filter(id, query) {
            this.setId = id;
            this.query = query;
        }
        return Filter;
    }());
    exports.Filter = Filter;
    var CsvRegexFiltering = (function () {
        function CsvRegexFiltering(sets, components, componentType, filterCallback, initialFilter) {
            var _this = this;
            this.addFilter = function () {
                _this.filters.push(new Filter());
            };
            this.removeFilter = function (filter) {
                _.remove(_this.filters, filter);
            };
            this.apply = function () {
                var filteredComponents = _this.components;
                var componentFilters = _.filter(_this.filters, function (f) { return f.setId === 'Component'; });
                if (componentFilters.length) {
                    var componentRegexQueries = _.map(componentFilters, function (cf) { return new RegExp(cf.query, 'i'); });
                    filteredComponents = _.filter(_this.components, function (c) { return _.some(componentRegexQueries, function (crq) { return c.name.search(crq) !== -1; }); });
                }
                var setFilters = _.filter(_this.filters, function (f) { return f.setId !== 'Component'; });
                var setFilterQueries = _.map(setFilters, function (f) {
                    return {
                        id: f.setId,
                        query: new RegExp(f.query, 'i'),
                    };
                });
                _this.filterCallback(filteredComponents, setFilterQueries);
            };
            this.clear = function () {
                _this.filters = [];
                _this.filterCallback(_this.components, []);
            };
            this.sets = sets;
            this.components = components;
            this.sets.unshift({
                id: 'Component',
                name: componentType,
                abbreviation: null,
                description: null,
                numeric: null,
            });
            this.filters = [];
            this.filterCallback = filterCallback;
            if (initialFilter) {
                if (initialFilter.filterType.toLowerCase() === componentType.toLowerCase()) {
                    var filteredComponent = _.find(this.components, function (c) { return c.id === initialFilter.filteredItemId; });
                    if (filteredComponent) {
                        this.filters.push(new Filter('Component', "^" + filteredComponent.name + "$"));
                    }
                }
                if (initialFilter.filterType.toLowerCase() === 'set' && _.some(this.sets, function (s) { return s.id === initialFilter.filteredItemId; })) {
                    this.filters.push(new Filter(initialFilter.filteredItemId, initialFilter.filterValue));
                }
                if (this.filters.length) {
                    this.apply();
                }
            }
        }
        return CsvRegexFiltering;
    }());
    exports.CsvRegexFiltering = CsvRegexFiltering;
    var DropdownFilter = (function () {
        function DropdownFilter(setDatas, components, initialComponentId, initialQuery) {
            var _this = this;
            this.selectComponent = function (componentId) {
                _this.selectedQuery = null;
                if (componentId === 'Component') {
                    _this.queryItems = _.map(_this.components, function (c) {
                        return {
                            id: c.id,
                            name: c.name,
                        };
                    });
                }
                else {
                    var actualSetData = _.find(_this.setDatas, function (sd) { return sd.setId === componentId; });
                    if (!actualSetData)
                        return;
                    _this.queryItems = _.map(actualSetData.items, function (sdi) {
                        var onlyDisplayValue = sdi.value === sdi.name || !sdi.name;
                        return {
                            id: sdi.value,
                            name: onlyDisplayValue ? sdi.value : sdi.value + " (" + sdi.name + ")",
                        };
                    });
                }
            };
            this.setDatas = setDatas;
            this.components = components;
            this.selectedComponentId = initialComponentId;
            this.queryItems = [];
            this.selectedQuery = null;
            if (initialComponentId) {
                this.selectComponent(initialComponentId);
                if (initialQuery) {
                    this.selectedQuery = initialQuery;
                }
            }
        }
        return DropdownFilter;
    }());
    var CsvDropdownFiltering = (function () {
        function CsvDropdownFiltering(sets, setDatas, components, componentType, filterCallback, initialFilter) {
            var _this = this;
            this.addFilter = function () {
                _this.filters.push(new DropdownFilter(_this.setDatas, _this.components));
            };
            this.removeFilter = function (filter) {
                _.remove(_this.filters, filter);
                _this.apply();
            };
            this.apply = function () {
                var filteredComponents = _this.components;
                var componentFilters = _.filter(_this.filters, function (f) { return f.selectedComponentId === 'Component'; });
                if (componentFilters.length) {
                    filteredComponents = _.filter(_this.components, function (c) { return _.some(componentFilters, function (cf) { return cf.selectedQuery === c.id; }); });
                }
                var setFilters = _.filter(_this.filters, function (f) { return f.selectedComponentId !== 'Component'; });
                var setFilterQueries = _.map(setFilters, function (f) {
                    return {
                        id: f.selectedComponentId,
                        query: new RegExp("^" + f.selectedQuery + "$", 'i'),
                    };
                });
                _this.filterCallback(filteredComponents, setFilterQueries);
            };
            this.clear = function () {
                _this.filters = [];
                _this.filterCallback(_this.components, []);
            };
            this.sets = sets;
            this.setDatas = setDatas;
            this.components = _.sortBy(components, function (c) { return c.name; });
            this.sets.unshift({
                id: 'Component',
                name: componentType,
                abbreviation: null,
                description: null,
                numeric: null,
            });
            this.filters = [];
            this.filterCallback = filterCallback;
            if (initialFilter) {
                if (initialFilter.filterType.toLowerCase() === componentType.toLowerCase()) {
                    var filteredComponent = _.find(this.components, function (c) { return c.id === initialFilter.filteredItemId; });
                    if (filteredComponent) {
                        this.filters.push(new DropdownFilter(this.setDatas, this.components, 'Component', initialFilter.filteredItemId));
                    }
                }
                if (initialFilter.filterType.toLowerCase() === 'set' && _.some(this.sets, function (s) { return s.id === initialFilter.filteredItemId; })) {
                    this.filters.push(new DropdownFilter(this.setDatas, this.components, initialFilter.filteredItemId, initialFilter.filterValue));
                }
                if (this.filters.length) {
                    this.apply();
                }
            }
        }
        return CsvDropdownFiltering;
    }());
    exports.CsvDropdownFiltering = CsvDropdownFiltering;
});
//# sourceMappingURL=csvFiltering.js.map