define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var SeriesLoader = (function () {
        function SeriesLoader($q, requests) {
            var _this = this;
            this.load = function () {
                _this.loading = true;
                _this.loadNextItem();
                return _this.deferred.promise;
            };
            this.loadNextItem = function () {
                if (_this.loadedCount === _this.totalCount) {
                    _this.loading = false;
                    _this.deferred.resolve(_this.results);
                    return;
                }
                _this.requests[_this.loadedCount]().then(function (res) {
                    _this.loadedCount++;
                    _this.results.push(res);
                    _this.loadNextItem();
                });
            };
            this.requests = requests;
            this.results = [];
            this.totalCount = this.requests.length;
            this.loadedCount = 0;
            this.deferred = $q.defer();
        }
        return SeriesLoader;
    }());
    exports.SeriesLoader = SeriesLoader;
});
//# sourceMappingURL=seriesLoader.js.map