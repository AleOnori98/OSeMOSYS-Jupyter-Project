define(["require", "exports", "node-uuid"], function (require, exports, uuid) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var ConstraintGroup = (function () {
        function ConstraintGroup(constraintGroup) {
            var _this = this;
            this.serialize = function () {
                return {
                    id: _this.id,
                    name: _this.name,
                    description: _this.description,
                };
            };
            if (constraintGroup) {
                this.id = constraintGroup.id;
                this.name = constraintGroup.name;
                this.description = constraintGroup.description;
            }
            else {
                this.id = uuid.v4();
                this.name = '';
                this.description = '';
            }
        }
        return ConstraintGroup;
    }());
    exports.ConstraintGroup = ConstraintGroup;
});
//# sourceMappingURL=constraintGroup.js.map