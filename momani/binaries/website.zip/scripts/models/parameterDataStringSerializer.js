define(["require", "exports", "lodash", "models/setData"], function (require, exports, _, setDataModel) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var ParameterData = (function () {
        function ParameterData(parameter, setDatas, parameterData) {
            var _this = this;
            this.asDataString = function () {
                var res = [];
                if (_this.setCount == 0) {
                    res.unshift("param " + _this.name + " default " + _this.defaultValue);
                    res.push(";");
                    return res;
                }
                if (_this.setCount == 1) {
                    _.forEach(_this.setDatas[0], function (val, index) {
                        if (_this.data[index] != _this.defaultValue) {
                            res.push(setDataModel.SetData.glpkReady(val) + " " + _this.data[index]);
                        }
                    });
                }
                else {
                    res = res.concat(_this.getMultidimensionlStrings([], _this.data));
                }
                res.unshift("param " + _this.name + " default " + _this.defaultValue + " :" + (_this.setCount != 2 || res.length == 0 ? '=' : ''));
                res.push(";");
                return res;
            };
            this.getMultidimensionlStrings = function (fixedValues, data) {
                if (_this.setCount - fixedValues.length > 2) {
                    var res = [];
                    _.forEach(data, function (dataValue, index) {
                        var value = _this.setDatas[fixedValues.length][index];
                        var fixed = fixedValues.concat([value]);
                        res = res.concat(_this.getMultidimensionlStrings(fixed, dataValue));
                    });
                    return res;
                }
                else {
                    return _this.get2DStrings(fixedValues, data);
                }
            };
            this.get2DStrings = function (fixedValues, data) {
                var res = [];
                _.forEach(_this.setDatas[_this.setCount - 2], function (val, valIndex) {
                    if (_.some(data[valIndex], function (d) { return d != _this.defaultValue; })) {
                        res.push(setDataModel.SetData.glpkReady(val) + " " + data[valIndex].join(' '));
                    }
                });
                if (res.length > 0) {
                    res.unshift(_this.setDatas[_this.setCount - 1].join(' ') + ":=");
                    if (fixedValues.length > 0) {
                        res.unshift("[" + fixedValues.join(',') + ",*,*]:");
                    }
                }
                return res;
            };
            this.name = parameter.name;
            this.setCount = setDatas.length;
            this.defaultValue = parameterData.defaultValue || parameter.defaultValue;
            if (this.setCount == 0) {
                this.defaultValue = parameterData.data.length > 0 ? _.first(parameterData.data).v : this.defaultValue;
                return;
            }
            var orderedSetDatas = _.map(parameterData.sets, function (s) {
                return _.find(setDatas, function (sd) { return sd.setId == s.id; });
            });
            if (_.some(orderedSetDatas, function (s) { return s == null; })) {
                orderedSetDatas = setDatas;
            }
            this.setDatas = _.map(orderedSetDatas, function (s) { return s.getValues(); });
            this.data = this.createArray(this.setDatas);
            this.loadData(parameterData.data);
        }
        ParameterData.prototype.createArray = function (setDatas) {
            var _this = this;
            var otherElements = setDatas.slice(1, setDatas.length);
            return _.map(_.first(setDatas), function () {
                return otherElements.length > 0 ? _this.createArray(otherElements) : _this.defaultValue;
            });
        };
        ParameterData.prototype.loadData = function (parameterData) {
            var _this = this;
            if (this.setDatas.length == 0) {
                this.defaultValue = parameterData && parameterData.length > 0 ? _.first(parameterData).v : this.defaultValue;
                return;
            }
            _.forEach(parameterData, function (item) {
                var coordinateIdexes = _this.mapToCoordinateIndexes(item.c);
                if (_.some(coordinateIdexes, function (i) { return i < 0; })) {
                    return;
                }
                _this.placeItem(_this.data, coordinateIdexes, item.v);
            });
        };
        ParameterData.prototype.placeItem = function (grid, coordinates, value) {
            var currentCoord = _.first(coordinates);
            if (coordinates.length == 1) {
                grid[currentCoord] = value;
                return;
            }
            this.placeItem(grid[currentCoord], coordinates.slice(1, coordinates.length), value);
        };
        ParameterData.prototype.mapToCoordinateIndexes = function (coordinates) {
            var _this = this;
            return _.map(coordinates, function (coord, index) {
                return _.indexOf(_this.setDatas[index], coord);
            });
        };
        return ParameterData;
    }());
    exports.ParameterData = ParameterData;
    function findDataItem(coords, data) {
        return _.find(data, function (d) { return hasSameCoordinates(coords, d.c); });
    }
    function hasSameCoordinates(coords1, coords2) {
        return _.every(coords1, function (c, index) { return c == coords2[index]; });
    }
});
//# sourceMappingURL=parameterDataStringSerializer.js.map