define(["require", "exports", "lodash", "node-uuid"], function (require, exports, _, uuid) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var DimensionSelector = (function () {
        function DimensionSelector(index, dimensions) {
            this.selected = '';
            this.dimensions = dimensions;
            this.selectorIndex = index;
        }
        return DimensionSelector;
    }());
    var ParameterData = (function () {
        function ParameterData(scenarioId, modelId, parameter, setDatas, parameterData) {
            var _this = this;
            this.dimensionSelectors = [];
            this.dimensionValues = [];
            this.spreadsheetItems = [];
            this.updateDimensions = function (index) {
                _this.saveSpreadsheetItems();
                _this.dimensionSelectors = _.take(_this.dimensionSelectors, index + 1);
                var changed = _.last(_this.dimensionSelectors);
                if (changed.selected) {
                    changed.selectedDimension = _.find(changed.dimensions, function (d) { return d.id == changed.selected; });
                    changed.dimensionValue = _.first(changed.selectedDimension.values).value;
                    var availableDimensions = _.filter(_this.dimensions, function (dimension) { return !_.some(_this.dimensionSelectors, function (ds) { return ds.selected == dimension.id; }); });
                    if (availableDimensions.length > 2) {
                        _this.hideSpreadsheet();
                        _this.dimensionSelectors.push(new DimensionSelector(_this.dimensionSelectors.length, availableDimensions));
                    }
                    else {
                        _this.dimensionValues = _(_this.dimensionSelectors).filter(function (s) { return s.selected; }).map(function (s) { return { id: s.selected, value: s.dimensionValue }; }).value();
                        _this.updateSpreadsheet(availableDimensions[0], availableDimensions[1]);
                    }
                }
            };
            this.changeDimensionValue = function () {
                if (_this.dimensions.length - _.filter(_this.dimensionSelectors, function (sel) { return sel.selected; }).length <= 2) {
                    _this.saveSpreadsheetItems();
                    _this.dimensionValues = _.map(_this.dimensionSelectors, function (s) { return { id: s.selected, value: s.dimensionValue }; });
                    _this.updateSpreadsheet(_this.rowSet, _this.colSet);
                }
            };
            this.switchAxes = function () {
                _this.spreadsheetVisible = false;
                _this.saveSpreadsheetItems();
                _this.updateSpreadsheet(_this.colSet, _this.rowSet);
            };
            this.serialize = function () {
                _this.saveSpreadsheetItems();
                return {
                    parameterId: _this.parameter.id,
                    scenarioId: _this.scenarioId,
                    modelId: _this.modelId,
                    defaultValue: _this.defaultValue,
                    sets: _.map(_this.dimensions, function (dimension) {
                        return {
                            id: dimension.setId,
                            index: dimension.index,
                        };
                    }),
                    data: _(_this.data).map(function (dataItem) {
                        var numValue = +dataItem.value.trim().replace(',', '.');
                        var value = isNaN(numValue) ? null : numValue;
                        return {
                            c: _.map(_this.dimensions, function (dimension) { return dataItem.dimensions[dimension.id]; }),
                            v: value,
                        };
                    }).filter(function (dataItem) {
                        return dataItem.v != _this.defaultValue && dataItem.v != null;
                    }).value(),
                };
            };
            this.hideSpreadsheet = function () {
                _this.spreadsheetVisible = false;
                _this.spreadsheetItems = [];
            };
            this.updateSpreadsheet = function (dimension1, dimension2) {
                if (_this.spreadsheetItems.length > 0) {
                    _this.hideSpreadsheet();
                    setTimeout(function () {
                        _this.setupSpreadsheet(dimension1, dimension2);
                    }, 0);
                }
                else {
                    _this.setupSpreadsheet(dimension1, dimension2);
                }
            };
            this.saveSpreadsheetItems = function () {
                if (_this.spreadsheetItems.length > 0) {
                    _this.data = _this.otherItems;
                    _.forEach(_this.rows, function (row, rowIndex) {
                        _.forEach(_this.columns, function (column, colIndex) {
                            var val = _this.spreadsheetItems[rowIndex][colIndex];
                            if (val != null && val != '') {
                                var dataItem = {
                                    dimensions: [],
                                    value: val,
                                };
                                _.forEach(_this.dimensionValues, function (dimensionValue) {
                                    dataItem.dimensions[dimensionValue.id] = dimensionValue.value;
                                });
                                dataItem.dimensions[_this.rowSet.id] = _this.rows[rowIndex];
                                if (_this.colSet) {
                                    dataItem.dimensions[_this.colSet.id] = _this.columns[colIndex];
                                }
                                _this.data.push(dataItem);
                            }
                        });
                    });
                }
                ;
            };
            this.scenarioId = scenarioId;
            this.modelId = modelId;
            this.parameter = parameter;
            this.setDatas = setDatas;
            this.dimensions = _.map(setDatas, function (setData, index) {
                var instanceIndex = _(setDatas).slice(0, index).filter(function (d) { return d.setId == setData.setId; }).value().length;
                return {
                    id: uuid.v4(),
                    setId: setData.setId,
                    name: setData.setName,
                    index: instanceIndex,
                    values: _.map(setData.getValueNamePairs(), function (valueName) {
                        var onlyDisplayValue = valueName.value == valueName.name || !valueName.name;
                        return {
                            value: valueName.value,
                            displayName: onlyDisplayValue ? valueName.value : valueName.value + " (" + valueName.name + ")",
                        };
                    }),
                };
            });
            if (parameterData.defaultValue != null) {
                this.defaultValue = parameterData.defaultValue;
                this.data = _.map(parameterData.data, function (item) {
                    var res = {
                        dimensions: [],
                        value: item.v.toString(),
                    };
                    _.forEach(item.c, function (coordinate, index) {
                        var dimensionId = _this.dimensions[index].id;
                        res.dimensions[dimensionId] = coordinate;
                    });
                    return res;
                });
            }
            else {
                this.defaultValue = parameter.defaultValue;
                this.data = [];
            }
            if (this.dimensions.length > 2) {
                this.dimensionSelectors.push(new DimensionSelector(this.dimensionSelectors.length, this.dimensions));
            }
            else {
                this.updateSpreadsheet(this.dimensions[0], this.dimensions[1]);
            }
        }
        ParameterData.prototype.setupSpreadsheet = function (dimension1, dimension2) {
            var _this = this;
            this.rowSet = dimension1;
            this.colSet = dimension2;
            var rowSetData = _.find(this.setDatas, function (sd) { return sd.setId == dimension1.setId; });
            var colSetData = dimension2 ? _.find(this.setDatas, function (sd) { return sd.setId == dimension2.setId; }) : null;
            this.rows = rowSetData.getValues();
            this.columns = colSetData ? colSetData.getValues() : [null];
            this.spreadsheetSettings = {
                colHeaders: dimension2 ? this.columns : false,
                rowHeaders: this.rows,
                maxRows: this.rows.length,
                maxCols: this.columns.length,
            };
            this.spreadsheetItems = _.map(this.rows, function () {
                return _.map(_this.columns, function () { return null; });
            });
            this.otherItems = [];
            _.forEach(this.data, function (dataItem) {
                var isActual = _.every(_this.dimensionValues, function (dimensionValue) {
                    return dataItem.dimensions[dimensionValue.id] == dimensionValue.value;
                });
                if (isActual) {
                    var rowIndex = _.indexOf(_this.rows, dataItem.dimensions[_this.rowSet.id]);
                    var colIndex = _this.colSet ? _.indexOf(_this.columns, dataItem.dimensions[_this.colSet.id]) : 0;
                    if (rowIndex < 0 || colIndex < 0)
                        return;
                    _this.spreadsheetItems[rowIndex][colIndex] = dataItem.value;
                }
                else {
                    _this.otherItems.push(dataItem);
                }
            });
            this.spreadsheetVisible = true;
        };
        return ParameterData;
    }());
    exports.ParameterData = ParameterData;
});
//# sourceMappingURL=parameterData.js.map