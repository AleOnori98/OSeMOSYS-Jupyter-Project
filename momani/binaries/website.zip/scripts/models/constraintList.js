define(["require", "exports", "lodash"], function (require, exports, _) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var ConstraintList = (function () {
        function ConstraintList(constraintGroups, constraints) {
            var _this = this;
            this.groups = _.map(constraintGroups, function (g) {
                return {
                    id: g.id,
                    name: g.name,
                    description: g.description,
                    constraints: [],
                };
            });
            this.ungrouped = [];
            _.forEach(constraints, function (c) {
                var group = _.find(_this.groups, function (g) { return g.id == c.constraintGroupId; });
                if (group == null) {
                    _this.ungrouped.push(c);
                }
                else {
                    group.constraints.push(c);
                }
            });
            this.groups = _.sortBy(this.groups, 'name');
            _.forEach(this.groups, function (g) {
                g.constraints = _.sortBy(g.constraints, 'name');
            });
            this.ungrouped = _.sortBy(this.ungrouped, 'name');
            this.flattened = [];
            _.forEach(this.groups, function (g) {
                _this.flattened.push({
                    name: g.name,
                    editLink: "#/constraintGroups/" + g.id,
                    css: 'constraint-group-row',
                });
                _.forEach(g.constraints, function (c) {
                    _this.flattened.push({
                        name: c.name,
                        constraintName: c.name,
                        description: c.description,
                        editLink: "#/constraints/" + c.id,
                        css: 'constraint-row',
                    });
                });
            });
            this.flattened.push({
                name: 'Ungrouped',
                css: 'constraint-group-row',
            });
            _.forEach(this.ungrouped, function (c) {
                _this.flattened.push({
                    name: c.name,
                    constraintName: c.name,
                    description: c.description,
                    editLink: "#/constraints/" + c.id,
                    css: 'constraint-row',
                });
            });
        }
        return ConstraintList;
    }());
    exports.ConstraintList = ConstraintList;
});
//# sourceMappingURL=constraintList.js.map