define(["require", "exports", "lodash"], function (require, exports, _) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var CsvBuilder = (function () {
        function CsvBuilder(dataset, sets, setDatas, variable) {
            var _this = this;
            this.getCsvBlob = function () {
                var content = _this.rows.join('\r\n');
                return _this.textToBlob(content, 'text/csv');
            };
            this.textToBlob = function (text, contentType, sliceSize) {
                contentType = contentType || '';
                sliceSize = sliceSize || 512;
                var byteArrays = [];
                for (var offset = 0; offset < text.length; offset += sliceSize) {
                    var slice = text.slice(offset, offset + sliceSize);
                    var byteNumbers = new Array(slice.length);
                    for (var i = 0; i < slice.length; i++) {
                        byteNumbers[i] = slice.charCodeAt(i);
                    }
                    var byteArray = new Uint8Array(byteNumbers);
                    byteArrays.push(byteArray);
                }
                var blob = new Blob(byteArrays, { type: contentType });
                return blob;
            };
            var actualSets = _.map(dataset.sets, function (ds) {
                return _.find(sets, function (s) { return s.id == ds.id; });
            });
            var otherSetCount = actualSets.length - 1;
            var otherSets = _.take(actualSets, otherSetCount);
            var actualSetDatas = _.map(actualSets, function (s) { return _.find(setDatas, function (sd) { return sd.setId == s.id; }); });
            var detailedSetData = _.last(actualSetDatas);
            var otherSetDatas = _.take(actualSetDatas, otherSetCount);
            var detailedSetDataValueCount = detailedSetData.items.length;
            this.rows = [];
            if (variable.unit) {
                this.rows.push(variable.unit);
            }
            var headerSetNames = _.map(otherSets, function (s) { return s.name; });
            var headerSetValues = _.map(detailedSetData.items, function (i) { return i.value; });
            var headerItems = headerSetNames.concat(headerSetValues);
            this.rows.push(headerItems.join(','));
            var coordinates = [];
            _.forEach(otherSetDatas, function (data) {
                var values = _.map(data.items, function (item) { return item.value; });
                coordinates = buildCoordinates(coordinates, values);
            });
            var dataRows = _.map(coordinates, function (c) {
                return {
                    coordinates: c.join(','),
                    values: _.map(_.range(detailedSetDataValueCount), function () { return dataset.defaultValue; })
                };
            });
            _.forEach(dataset.data, function (data) {
                var coordinates = _.take(data.c, otherSetCount).join(',');
                var index = _.indexOf(headerSetValues, _.last(data.c));
                if (index < 0)
                    return;
                var row = _.find(dataRows, function (r) { return r.coordinates === coordinates; });
                if (row == null)
                    return;
                row.values[index] = data.v;
            });
            _.forEach(dataRows, function (data) {
                var valuesString = data.values.join(',');
                var row = [data.coordinates, valuesString].join(',');
                _this.rows.push(row);
            });
        }
        return CsvBuilder;
    }());
    exports.CsvBuilder = CsvBuilder;
    function buildCoordinates(existingRows, additionalValues) {
        if (existingRows.length == 0) {
            return _.map(additionalValues, function (value) { return [value]; });
        }
        var res = [];
        _.forEach(existingRows, function (row) {
            _.forEach(additionalValues, function (value) {
                res.push(row.concat(value));
            });
        });
        return res;
    }
});
//# sourceMappingURL=csvBuilder.js.map