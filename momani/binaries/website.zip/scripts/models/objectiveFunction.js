define(["require", "exports", "node-uuid", "models/equationObject"], function (require, exports, uuid, equationObject) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var ObjectiveFunction = (function () {
        function ObjectiveFunction(data, modal, objectiveFunction) {
            var _this = this;
            this.serialize = function () {
                return {
                    id: _this.id,
                    name: _this.name,
                    description: _this.description,
                    function: _this.function,
                    equation: _this.equation.serialize(),
                };
            };
            this.replaceEquation = function (equation) {
                _this.equation = equationObject.createEquationObject(_this.data, equationObject.availableGroupOptions.all, _this.replaceEquation, _this.modal, equation);
            };
            this.getDependencies = function () {
                return _this.equation.getDependencies();
            };
            this.asModelString = function () {
                return _this.function.toLowerCase() + " " + _this.name + ": " + _this.equation.asString() + ";";
            };
            this.data = data;
            this.modal = modal;
            if (objectiveFunction) {
                this.id = objectiveFunction.id;
                this.name = objectiveFunction.name;
                this.description = objectiveFunction.description;
                this.function = objectiveFunction.function;
                this.equation = equationObject.createEquationObject(data, equationObject.availableGroupOptions.all, this.replaceEquation, modal, objectiveFunction.equation);
            }
            else {
                this.id = uuid.v4();
                this.name = '';
                this.description = '';
                this.function = 'Minimize';
                this.equation = equationObject.createEquationObject(data, equationObject.availableGroupOptions.all, this.replaceEquation, modal);
            }
        }
        return ObjectiveFunction;
    }());
    exports.ObjectiveFunction = ObjectiveFunction;
});
//# sourceMappingURL=objectiveFunction.js.map