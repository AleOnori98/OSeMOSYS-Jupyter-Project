define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var EquationObjectSet = (function () {
        function EquationObjectSet(set, occurence) {
            var _this = this;
            this.applyChanges = function (changeCollection) {
                if (changeCollection == null || changeCollection.setId !== _this.setId || changeCollection.changes == null)
                    return;
                var renames = _.filter(changeCollection.changes, function (change) { return change.changeType === 'Rename'; });
                var rename = _.last(renames);
                var increments = _.filter(changeCollection.changes, function (change) { return change.changeType === 'Increment'; });
                var increment = _.last(increments);
                _this.actualAbbreviation = rename ? rename.changeValue : _this.initialAbbreviation;
                _this.increment = increment ? +increment.changeValue : null;
            };
            this.getChanges = function () {
                var changes = [];
                if (_this.initialAbbreviation !== _this.actualAbbreviation) {
                    changes.push({ changeType: 'Rename', changeValue: _this.actualAbbreviation });
                }
                if (_this.increment != null) {
                    changes.push({ changeType: 'Increment', changeValue: _this.increment.toString() });
                }
                return {
                    setId: _this.setId,
                    changes: changes,
                };
            };
            this.render = function () {
                var render = _this.actualAbbreviation;
                if (_this.increment) {
                    if (_this.increment > 0) {
                        render += "+" + _this.increment.toString();
                    }
                    else if (_this.increment < 0) {
                        render += _this.increment.toString();
                    }
                }
                return render;
            };
            this.setId = set.id;
            this.name = set.name;
            this.initialAbbreviation = _.repeat(set.abbreviation, occurence);
            this.actualAbbreviation = this.initialAbbreviation;
            this.increment = null;
        }
        return EquationObjectSet;
    }());
    exports.EquationObjectSet = EquationObjectSet;
});
//# sourceMappingURL=equationObjectSet.js.map