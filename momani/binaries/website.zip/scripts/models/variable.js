define(["require", "exports", "node-uuid"], function (require, exports, uuid) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var VariableConstraint = (function () {
        function VariableConstraint(constraint) {
            if (constraint) {
                this.operator = constraint.operator;
                this.value = constraint.value;
            }
            else {
                this.operator = 'Gte';
                this.value = 0;
            }
        }
        return VariableConstraint;
    }());
    exports.VariableConstraint = VariableConstraint;
    var VariableSet = (function () {
        function VariableSet(value) {
            this.id = uuid.v4();
            this.value = value;
        }
        return VariableSet;
    }());
    exports.VariableSet = VariableSet;
    var Variable = (function () {
        function Variable(setOptions, variable) {
            var _this = this;
            this.addSet = function () {
                var firstSet = _.first(_this.setOptions);
                if (!firstSet)
                    return;
                _this.sets.push(new VariableSet(firstSet.id));
            };
            this.removeSet = function (set) {
                _.remove(_this.sets, set);
            };
            this.render = function () {
                return '';
            };
            this.getInternalSets = function () {
                return _.map(_this.sets, function (variableSet, index) {
                    var set = _.find(_this.setOptions, function (so) { return so.id == variableSet.value; });
                    var sameSetCount = _(_this.sets).take(index).filter(function (s) { return s.value == set.id; }).value().length;
                    return {
                        set: set,
                        index: sameSetCount,
                        actualAbbreviation: Array(sameSetCount + 2).join(set.abbreviation),
                    };
                });
            };
            this.asModelString = function () {
                var setDefinitions = _.map(_this.getInternalSets(), function (internalSet) { return internalSet.actualAbbreviation + " in " + internalSet.set.name; });
                var internalSetDefinitionsString = _this.sets.length > 0 ? "{" + setDefinitions.join(', ') + "}" : "";
                var res = "var " + _this.name + internalSetDefinitionsString;
                if (_this.constraint) {
                    var operator = _.find(exports.variableOperators, function (vo) { return vo.id == _this.constraint.operator; });
                    res += " " + operator.name + " " + _this.constraint.value;
                }
                if (_this.integer) {
                    res += ", integer";
                }
                return res + ";";
            };
            this.asOutputString = function () {
                var internalSets = _this.getInternalSets();
                var setDefinitions = _.map(internalSets, function (internalSet) { return internalSet.actualAbbreviation + " in " + internalSet.set.name; });
                var internalSetDefinitionsString = _this.sets.length > 0 ? "" + setDefinitions.join(', ') : "mock in {1}";
                var internalSetAbbreviationsString = _.map(internalSets, function (internalSet) { return internalSet.actualAbbreviation; }).join(', ');
                var columnListString = _this.sets.length > 0 ? internalSetAbbreviationsString + ", " : "";
                var setParameterListString = _this.sets.length > 0 ? "[" + internalSetAbbreviationsString + "]" : "";
                return "table tout {" + internalSetDefinitionsString + "} OUT \"CSV\" \"res/csv/" + _this.name + ".csv\" : " + columnListString + _this.name + setParameterListString + ";";
            };
            this.asMetaData = function () {
                var sets = _.map(_this.sets, function (s) { return s.value; }).join(',');
                var setStringPart = _this.sets.length > 0 ? "," + sets : "";
                return _this.name + "," + _this.id + setStringPart;
            };
            this.setOptions = setOptions;
            if (variable) {
                this.id = variable.id;
                this.name = variable.name;
                this.description = variable.description;
                this.sets = _.map(variable.sets, function (setId) {
                    return new VariableSet(setId);
                });
                this.constraint = variable.constraint ? new VariableConstraint(variable.constraint) : null;
                this.integer = variable.integer;
                this.unit = variable.unit;
            }
            else {
                this.id = uuid.v4();
                this.name = '';
                this.description = '';
                this.sets = [];
                this.constraint = null;
                this.integer = false;
                this.unit = null;
            }
        }
        Variable.prototype.serialize = function () {
            return {
                id: this.id,
                name: this.name,
                description: this.description,
                sets: _.map(this.sets, function (set) { return set.value; }),
                constraint: this.constraint,
                integer: this.integer,
                unit: this.unit,
            };
        };
        return Variable;
    }());
    exports.Variable = Variable;
    exports.variableOperators = [
        { id: 'Gte', name: '>=' },
        { id: 'Lte', name: '<=' },
        { id: 'Gt', name: '>' },
        { id: 'Lt', name: '<' },
        { id: 'Eq', name: '=' },
        { id: 'Ne', name: '<>' },
    ];
});
//# sourceMappingURL=variable.js.map