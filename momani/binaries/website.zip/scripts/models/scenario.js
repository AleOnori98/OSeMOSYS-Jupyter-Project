define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var Scenario = (function () {
        function Scenario(scenario) {
            var _this = this;
            this.serialize = function () {
                return {
                    id: _this.id,
                    modelId: _this.modelId,
                    parentScenarioId: null,
                    name: _this.name,
                    description: _this.description,
                    revision: _this.revision,
                    hasResults: null,
                };
            };
            this.id = scenario.id;
            this.modelId = scenario.modelId;
            this.name = scenario.name;
            this.description = scenario.description;
            this.revision = scenario.revision;
        }
        return Scenario;
    }());
    exports.Scenario = Scenario;
});
//# sourceMappingURL=scenario.js.map