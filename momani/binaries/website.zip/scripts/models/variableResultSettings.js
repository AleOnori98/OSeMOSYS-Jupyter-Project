define(["require", "exports", "lodash"], function (require, exports, _) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var SetDataGroup = (function () {
        function SetDataGroup(id, name, items, changeHandler) {
            var _this = this;
            this.id = id;
            this.name = name;
            this.items = _.map(items, function (i) {
                return {
                    data: i,
                    selected: true,
                };
            });
            this.selected = true;
            this.toggleGroupItems = function (checked) {
                var checkbox = checked.target;
                _.forEach(_this.items, function (i) { i.selected = checkbox.checked; });
                changeHandler();
            };
            this.selectedItems = function () {
                return _(_this.items).filter(function (i) { return i.selected; }).map(function (i) { return i.data; }).value();
            };
        }
        return SetDataGroup;
    }());
    exports.SetDataGroup = SetDataGroup;
    var VariableResultSettings = (function () {
        function VariableResultSettings() {
            var _this = this;
            this.addLegendSubscriber = function (subscriber) {
                _this.legendSubscribers.push(subscriber);
            };
            this.toggleLegend = function ($event) {
                var checkbox = $event.target;
                _this.legendVisible = checkbox.checked;
                _.forEach(_this.legendSubscribers, function (subscriber) {
                    subscriber(_this.legendVisible);
                });
            };
            this.addUseSetDataDescriptionSubscriber = function (subscriber) {
                _this.useSetDataDescriptionsSubscribers.push(subscriber);
            };
            this.toggleUseSetDataDescriptions = function ($event) {
                var checkbox = $event.target;
                _this.useSetDataDescriptions = checkbox.checked;
                _.forEach(_this.useSetDataDescriptionsSubscribers, function (subscriber) {
                    subscriber(_this.useSetDataDescriptions);
                });
            };
            this.toggleAllSetGroupItems = function ($event) {
                var checkbox = $event.target;
                _this.allSelected = checkbox.checked;
                _.forEach(_this.setDataGroups, function (setDataGroup) {
                    setDataGroup.selected = checkbox.checked;
                    _.forEach(setDataGroup.items, function (item) {
                        item.selected = checkbox.checked;
                    });
                });
                _this.notifySetDataFilterSubscribers();
            };
            this.updateSetData = function (setData) {
                var groups = setData && setData.groups ? setData.groups : [];
                var items = setData && setData.items ? setData.items : [];
                var sortedGroups = _.sortBy(groups, function (g) { return g.name; });
                var groupList = _.map(sortedGroups, function (g) {
                    var groupSetData = _.filter(items, function (i) { return i.groupId == g.id; });
                    return new SetDataGroup(g.id, g.name, groupSetData, _this.notifySetDataFilterSubscribers);
                });
                var ungroupedItems = _.filter(items, function (c) { return c.groupId == null; });
                groupList.push(new SetDataGroup(null, 'Ungrouped', ungroupedItems, _this.notifySetDataFilterSubscribers));
                _this.setDataGroups = groupList;
                _this.notifySetDataFilterSubscribers();
            };
            this.addSetDataFilterSubscriber = function (subscriber) {
                _this.setDataFilterSubscribers.push(subscriber);
            };
            this.toggleSetData = function ($event, setDataOption) {
                var checkbox = $event.target;
                setDataOption.selected = checkbox.checked;
                _this.notifySetDataFilterSubscribers();
            };
            this.notifySetDataFilterSubscribers = function () {
                var selectedSetDataOptions = _.flatten(_.map(_this.setDataGroups, function (g) { return g.selectedItems(); }));
                var selectedSetDataValues = _.map(selectedSetDataOptions, function (sdo) { return sdo.value; });
                _.forEach(_this.setDataFilterSubscribers, function (subscriber) {
                    subscriber(selectedSetDataValues);
                });
            };
            this.addChartHeightSubscriber = function (subscriber) {
                _this.chartHeightSubscribers.push(subscriber);
            };
            this.notifyChartHeightSubscribers = function () {
                _.forEach(_this.chartHeightSubscribers, function (subscriber) {
                    subscriber(_this.chartHeight);
                });
            };
            this.displayForNameValue = function (name, value) {
                return value == name ? value : value + " (" + name + ")";
            };
            this.chartHeight = 500;
            this.visible = false;
            this.legendVisible = true;
            this.legendSubscribers = [];
            this.useSetDataDescriptions = true;
            this.useSetDataDescriptionsSubscribers = [];
            this.setDataFilterSubscribers = [];
            this.chartHeightSubscribers = [];
            this.allSelected = true;
        }
        return VariableResultSettings;
    }());
    exports.VariableResultSettings = VariableResultSettings;
});
//# sourceMappingURL=variableResultSettings.js.map